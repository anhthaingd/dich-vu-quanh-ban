# 05 — Kết nối MCP hỗ trợ phát triển mobile

DOC-077 · v1.1 · 30/09/2026 · MCP-01 · [Mục lục](README.md).

**Đầu vào:** thiết bị ảo đã chạy; muốn thử tương tác app thì hoàn thành bài 04. **Đầu ra:** AI thực sự nhìn và thao tác đúng thiết bị; không chỉ có tên MCP trong cấu hình.

## 1. Mobile MCP trước

[Mobile MCP](https://github.com/mobile-next/mobile-mcp) hỗ trợ thiết bị Android/iOS, đọc UI, chụp ảnh, tap, nhập chữ, vuốt và mở app. Công cụ này không thay SDK, simulator, compiler hoặc code ứng dụng.

Trong Terminal kiểm:

```bash
codex mcp list
```

Trên máy dự án đã cài **`@mobilenext/mobile-mcp@1.0.5`** ngày 30/09/2026. Không chạy `add` lần nữa. Kiểm bằng:

```bash
codex mcp get mobile-mcp
```

Cấu hình nằm trong `~/.codex/config.toml`, ngoài repo. Server dùng `/opt/homebrew/bin/npx -y @mobilenext/mobile-mcp@1.0.5`, đã giữ các MCP hiện có và đặt môi trường riêng cho process:

```toml
[mcp_servers.mobile-mcp]
command = "/opt/homebrew/bin/npx"
args = ["-y", "@mobilenext/mobile-mcp@1.0.5"]

[mcp_servers.mobile-mcp.env]
MOBILEMCP_DISABLE_TELEMETRY = "1"
ANDROID_HOME = "/Users/j2866/Library/Android/sdk"
DEVELOPER_DIR = "/Applications/Xcode.app/Contents/Developer"
PATH = "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/Users/j2866/Library/Android/sdk/platform-tools:/Users/j2866/Library/Android/sdk/emulator"
```

Đây là cấu hình đã kiểm trên Mac hiện tại. Máy khác phải xác minh lại đường dẫn bằng `command -v npx`, `xcode-select -p` và vị trí Android SDK; không chép nguyên tên người dùng. Khi cài mới, dùng `codex mcp add mobile-mcp --env KEY=VALUE ... -- /duong/dan/npx -y @mobilenext/mobile-mcp@1.0.5`, thay `KEY=VALUE` bằng từng biến đã kiểm ở trên. Không thêm package này vào `apps/mobile/package.json`. [Cấu hình Codex MCP](https://learn.chatgpt.com/docs/extend/mcp?surface=cli).

Phiên bản đang dùng điều khiển iOS Simulator qua `mobilecli`; không cần cài `idb` theo các bài cũ. Lần đầu đọc UI gặp `Agent is not installed on the device`: đã dùng binary `mobilecli` đi kèm MCP chạy `agent install --device <UUID>` và kiểm lại thành công. Helper **Device Kit 0.0.27**, bundle ID `com.mobilenext.devicekit-iosUITests.xctrunner`, chỉ cài vào simulator. Nếu xóa/tạo lại simulator, Codex cần xác định lại binary đi kèm phiên bản MCP, xem `agent install --help` rồi cài helper cho đúng UUID; không hardcode đường dẫn npm cache của máy cũ.

## 2. Kiểm kết nối trong phiên Codex

Mở phiên mới hoặc khởi động lại Codex nếu công cụ chưa hiện. Với giao diện dùng cấu hình MCP riêng, kiểm danh sách công cụ của chính phiên đó; cài CLI thành công không đảm bảo mọi ứng dụng AI tự dùng cùng cấu hình.

Nếu chưa build app, kiểm kết nối bằng yêu cầu:

> Dùng Mobile MCP liệt kê thiết bị Android và iOS đang chạy. Với từng thiết bị, đọc UI, chụp màn hình, bấm mở một màn hệ thống an toàn rồi chụp ảnh sau thao tác. Không thay cài đặt. Cuối cùng về Home.

Sau khi hoàn thành bài04 C, kiểm riêng app dự án:

> Dùng Mobile MCP liệt kê thiết bị. Chọn đúng máy ảo Dịch vụ quanh bạn đang chạy, chụp màn hình hiện tại, rồi mở app và chọn Điện nước. Báo lại phần tử đã bấm và ảnh sau thao tác.

Điều kiện đạt:

- Có tool gọi thành công và đúng device ID.
- Ảnh là từ máy ảo đang chạy.
- Tap thật làm màn hình thay đổi; ghi rõ đó là màn hệ thống hay app dự án, không nhầm với thao tác trên web.

Nếu danh sách trống, kiểm `adb devices` hoặc `xcrun simctl list devices booted`. Nếu Terminal thấy thiết bị nhưng MCP không thấy, kiểm PATH của process MCP; app GUI có thể không đọc `.zshrc`. Codex sẽ cấu hình đường dẫn SDK cho MCP sau khi xác minh vị trí cài đặt, không cài thêm server khác để che lỗi PATH.

## 3. Expo MCP — bổ sung khi cần

[Expo MCP](https://docs.expo.dev/mcp/) hỗ trợ tài liệu, dependency, build và một số thao tác local/DevTools. Dùng tài khoản Expo cho OAuth:

```bash
codex mcp add expo --url https://mcp.expo.dev/mcp
codex mcp login expo
```

Bỏ qua dòng `add` nếu server đã có. Hoàn thành đăng nhập trên trình duyệt. Kết nối GitHub của bạn không tự thay cho đăng nhập Expo.

Chỉ khi triển khai thêm tính năng local, Codex sẽ thực hiện trong mobile workspace:

```bash
cd /Users/j2866/Documents/anhthai/dich-vu-quanh-ban/apps/mobile
npx expo install expo-mcp --dev
npx expo whoami
```

Nếu chưa đăng nhập CLI, chạy `npx expo login` và dùng cùng tài khoản OAuth. Khởi động Metro cho iOS:

```bash
EXPO_UNSTABLE_MCP_SERVER=1 EXPO_PUBLIC_API_URL=http://127.0.0.1:3100/v1 npx expo start --dev-client --localhost
```

Android emulator dùng URL `http://10.0.2.2:3100/v1`. Kết nối lại MCP khi khởi động/dừng server để làm mới capability. Tính năng local có thể khác nhau giữa nền tảng; xác minh tool được expose trước khi hứa khả năng tự động hóa.

Expo hiện ghi `search_documentation` cần EAS paid plan. Bộ hướng dẫn không yêu cầu mua EAS, build cloud hoặc gửi bản TestFlight; Mobile MCP và tài liệu web đủ cho chặng local đầu tiên.

## 4. Sau khi cài

Ghi MCP name/version, nền tảng, tool đã gọi và kết quả trong biên bản bài 06. Cấu hình/tài khoản nằm trên máy, không đưa token vào Git. Chưa cần thêm XcodeBuildMCP vì phần build hiện có thể chạy bằng Expo CLI; chỉ bổ sung nếu gặp nhu cầu debug native cụ thể.

## 5. Kết quả trên máy dự án — 30/09/2026

Đã gọi giao thức MCP stdio bằng chính command/args/env đọc từ cấu hình Codex: initialize thành công, 32 tool được công bố, liệt kê đúng cả hai máy. Đọc UI, chụp ảnh, tap và HOME thành công trên Android/iOS. Chi tiết thao tác và giới hạn ở [biên bản bài06](06-kiem-thu-log.md#9-biên-bản-mcp-01--30092026).

**Việc bạn cần làm:** mở phiên Codex mới. Nếu tool chưa xuất hiện, trong VS Code mở Command Palette (`Cmd+Shift+P`), chạy `Developer: Reload Window` rồi mở lại Codex. Phiên thực hiện cấu hình chưa nạp lại danh sách tool, nên kết quả trên là kiểm giao thức/server thật; việc tool xuất hiện trong phiên IDE mới còn cần xác nhận. Không phải cài lại server.

Expo MCP chưa kết nối vì là phần bổ sung, không bắt buộc để điều khiển máy ảo. Chưa nghiệm thu luồng ngành/nhóm/kỹ năng native vì chưa build/cài binary sản phẩm.
