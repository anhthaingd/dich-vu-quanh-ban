# Bắt đầu phát triển app Android và iOS

DOC-072 · v1.0 · 29/09/2026 · MOBILE-GUIDE-01.

Bộ hướng dẫn dành cho chủ dự án Dịch vụ quanh bạn. Mục tiêu là cài công cụ trên Mac, chạy luồng danh mục bằng app native, kiểm tra bằng MCP/Maestro, rồi hoàn thiện khung giao diện trước khi mở rộng nghiệp vụ.

## Bắt đầu ở đâu?

1. Đọc [01 — Kiểm tra máy và cách dùng Terminal](01-chuan-bi-may.md).
2. Làm [02 — Android Studio và máy ảo](02-android.md) hoặc [03 — Xcode và iOS Simulator](03-ios.md). Có thể cài cả hai; chỉ cần mở một máy ảo khi bắt đầu.
3. Khi một thiết bị ảo đã chạy, chuyển sang [04 — Chạy API và development build](04-chay-app.md). Phần chuẩn bị native trong bài này có thay đổi code, được ghi riêng để phối hợp với Codex.
4. Kết nối [05 — MCP](05-mcp.md), sau đó chạy [06 — Kiểm thử và log](06-kiem-thu-log.md).
5. Thực hiện [07 — Kế hoạch hoàn thiện khung app](07-ke-hoach-khung-app.md).
6. Khi gặp lỗi, tra [08 — Xử lý lỗi](08-xu-ly-loi.md).

## Hiện trạng đã kiểm ngày 29/09/2026

| Hạng mục | Quan sát trên máy/repo | Việc tiếp theo |
|---|---|---|
| macOS | `27.0`, build `26A428`; Apple Silicon | Không còn bước nâng từ macOS 14.6 |
| Node/npm | Repo khóa Node `24.7.0`, npm `11.5.1` | Kiểm lại bằng bài 01, giữ phiên bản repo |
| Xcode | Chỉ có Command Line Tools; chưa có `/Applications/Xcode.app` | Bài 03 |
| Android Studio/SDK | Chưa có ở vị trí mặc định; `adb`/`emulator` chưa trong PATH | Bài 02 |
| Java | `java -version` báo chưa tìm được runtime | Bài 02 |
| Maestro/CocoaPods | Chưa tìm thấy `maestro`/`pod` trong PATH | Bài 06/bài 03 |
| App | Expo `57.0.25`, React Native `0.86.3`; đã có màn danh mục | Chưa thêm `expo-dev-client` và iOS bundle ID |
| Kiểm native | Có script preflight/flow; chưa có binary và chưa nghiệm thu | Không coi web/bundle build là bằng chứng native |

macOS 27 đã xác nhận bằng lệnh, nhưng **chưa xác nhận native build tương thích thành công**. Expo SDK 57 yêu cầu Xcode 26.4+; trên macOS 27 chọn Xcode stable được Apple liệt kê hỗ trợ hệ điều hành này, ví dụ Xcode 27 trong bảng hiện tại. Không tải lại Xcode 16 theo hướng dẫn cũ. [Expo SDK](https://docs.expo.dev/versions/latest/), [Apple Xcode](https://developer.apple.com/xcode/system-requirements).

## Phân biệt các công cụ

| Công cụ | Vai trò |
|---|---|
| Expo/React Native | Viết và chạy app Android/iOS từ phần lớn code TypeScript dùng chung |
| Metro | Máy chủ gửi JavaScript cho development build, thường ở cổng 8081 |
| Android Emulator/iOS Simulator | Thiết bị ảo để cài và chạy app |
| NestJS API | Backend dự án, cổng local 3100 |
| PostgreSQL/PostGIS | DB trong Docker, cổng local 55432; DB test 55433 |
| Mobile MCP | Cho AI nhìn và thao tác thiết bị đang chạy |
| Maestro | Chạy lại kịch bản kiểm thử native |
| Playwright | Kiểm thử bản web; không thay thế kiểm native |

## Ai làm phần nào?

- **Bạn:** cài ứng dụng qua giao diện, chấp nhận license sau khi đọc, nhập mật khẩu quản trị trên máy, đăng nhập Apple/Expo nếu cần, mở máy ảo và xem UI.
- **Codex:** kiểm tra môi trường, chuẩn bị development build, sửa app/config/test, xử lý lỗi, đối chiếu thiết kế và cập nhật tài liệu.
- **Cùng kiểm:** luồng thật, ảnh màn hình, lỗi và kết quả test trên từng nền tảng.

Đây là đợt **tạo hướng dẫn**, chưa cài công cụ, thay dependency, build native hay triển khai chức năng mới. Các bước tiếp theo giữ giới hạn local/test; không production hoặc tiền thật. Việc chọn navigation/UI trong bài 07 là kế hoạch, chưa là quyết định thư viện đã triển khai.

## Tài liệu liên quan và phiên bản

- [Bản đồ code DOC-070](../implementation/project-structure.md).
- [Log/test đã triển khai DOC-071](../implementation/logging-testing.md).
- [Phạm vi triển khai DOC-064](../handoff/CODEX-IMPLEMENTATION-PROMPT.md).
- [Sổ quản lý](../project-control/So-quan-ly-tai-lieu.xlsx): DOC-072–080 là các bài; DOC-081 là gói xuất.

Nguồn chính là 9 file Markdown trong thư mục này. Gói [huong-dan-mobile-v1.0.zip](huong-dan-mobile-v1.0.zip) chứa đúng các file đó; giải nén vào `docs/huong-dan-mobile/` trong repo để các liên kết sang tài liệu khác hoạt động. Không có bản HTML/localhost riêng trong đợt này. Các runbook ngày 28/09 giữ bằng chứng của đợt trước; bài 01 là mốc kiểm máy sau nâng macOS.

Khi sửa nội dung, tăng phiên bản phù hợp, tái tạo ZIP, cập nhật sổ và Drive cùng ID. Không sửa kết quả test cũ thành kết quả của máy sau nâng cấp.
