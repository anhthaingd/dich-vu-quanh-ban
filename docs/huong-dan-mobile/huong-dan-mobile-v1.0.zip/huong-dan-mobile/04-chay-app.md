# 04 — Chạy API và app native

DOC-076 · v1.0 · 29/09/2026 · [Mục lục](README.md).

**Điều kiện:** hoàn thành bài 01 và có Android emulator hoặc iOS simulator đang chạy. Các lệnh native phía dưới chỉ chạy **sau phần B**. Ở phiên bản tài liệu này, phần B là việc cần thực hiện, chưa có trong code.

## A. Chạy backend hiện có

### Terminal A — DB và API

Mở Docker Desktop, sau đó:

```bash
cd /Users/j2866/Documents/anhthai/dich-vu-quanh-ban
node --version
npm --version
npm ci
```

Node cần `v24.7.0`, npm `11.5.1`. `npm ci` cài đúng lockfile; không thay bằng cập nhật dependency hàng loạt. Chỉ chạy lại khi mới clone hoặc dependency thay đổi.

Tạo cấu hình local nếu chưa có; lệnh này giữ nguyên file đã tồn tại:

```bash
test -f services/api/.env || cp services/api/.env.example services/api/.env
test -f apps/mobile/.env || cp apps/mobile/.env.example apps/mobile/.env
npm run db:up
npm run db:migrate
npm run db:seed
npm run api
```

API phải chạy và giữ Terminal A bận. DB làm việc là `dvqb_local` ở cổng 55432; không đổi sang DB test. Nếu log báo cổng 3100 đã dùng, tra bài 08 để xác định process, không chạy thêm API thứ hai.

### Terminal B — kiểm API

```bash
curl --fail --show-error http://127.0.0.1:3100/v1/ready
```

**Đạt:** `{"status":"ready"}`. Nếu trả 503, kiểm Docker/migration/seed trước khi sửa mobile.

## B. Chuẩn bị development build — Codex thực hiện trước

Yêu cầu Codex làm trọn nhóm sau, kiểm diff rồi mới chạy native:

1. Đọc sổ quản lý mới nhất, bảo toàn thay đổi hiện có.
2. Thêm `expo-dev-client` bằng Expo CLI trong workspace mobile; kiểm tương thích và lockfile.
3. Bổ sung `ios.bundleIdentifier`; đề xuất dùng `vn.dichvuquanhban.app` cho local, thống nhất với Android hiện có. Chốt app ID trước khi gắn tài khoản store sau này.
4. Thêm scheme rõ ràng nếu cần deep link mở development client/automation; không coi scheme đề xuất là đã tồn tại.
5. Chọn Expo CNG: cấu hình trong `app.json`/plugin; thêm `/apps/mobile/android/` và `/apps/mobile/ios/` vào `.gitignore` trước khi sinh project nếu quyết định không track chúng. Không xóa native project có chỉnh sửa thủ công.
6. Kiểm cấu hình HTTP local của debug build; nếu cần ngoại lệ cleartext/ATS, giới hạn cho môi trường phát triển, không bật cho bản phát hành.
7. Thêm lệnh chạy theo nền tảng và ghi chính xác API URL, binary output, môi trường vào runbook.

Lệnh cài development client khi thực hiện nhóm trên:

```bash
cd /Users/j2866/Documents/anhthai/dich-vu-quanh-ban/apps/mobile
npx expo install expo-dev-client
npx expo install --check
```

Đây là lệnh **thay dependency**, không phải lệnh kiểm máy. Native folders sẽ được Expo sinh khi thiếu; không tạo folder rỗng, không dùng `prebuild --clean` như bước sửa lỗi mặc định. [Development build](https://docs.expo.dev/develop/development-builds/introduction/), [CNG](https://docs.expo.dev/workflow/continuous-native-generation/).

## C. Build lần đầu trên một nền tảng

Giữ Terminal A chạy API. Trong Terminal B:

### Android

```bash
cd /Users/j2866/Documents/anhthai/dich-vu-quanh-ban/apps/mobile
EXPO_PUBLIC_API_URL=http://10.0.2.2:3100/v1 npx expo run:android --device
```

Chọn emulator đã tạo ở bài 02 khi CLI hỏi. Chờ Gradle tải dependency/build/cài app, sau đó Metro chạy. Nếu không tự mở app, mở icon Dịch vụ quanh bạn trên emulator và chọn development server.

### iOS

```bash
cd /Users/j2866/Documents/anhthai/dich-vu-quanh-ban/apps/mobile
EXPO_PUBLIC_API_URL=http://127.0.0.1:3100/v1 npx expo run:ios --device
```

Chọn **simulator**, không chọn iPhone thật. Chờ Pods/build/cài app. Các lệnh `run:*` vừa build native, vừa cài và khởi động Metro; lần đầu lâu hơn lần sau. [Expo local build](https://docs.expo.dev/guides/local-app-development/).

## D. Những lần chạy tiếp theo

Nếu chỉ sửa TypeScript/giao diện và binary vẫn còn cài trên máy ảo, dùng Metro:

```bash
cd /Users/j2866/Documents/anhthai/dich-vu-quanh-ban/apps/mobile
EXPO_PUBLIC_API_URL=http://10.0.2.2:3100/v1 npx expo start --dev-client --localhost
```

Đây là lệnh cho Android emulator. Nhấn `a` để mở Android. Với iOS, dừng Metro bằng `Control + C`, chạy lại cùng lệnh nhưng đổi URL thành `http://127.0.0.1:3100/v1`, rồi nhấn `i`.

**Chạy lần lượt hai nền tảng** để tránh một Metro dùng sai URL cho nền tảng còn lại. Khi đổi native dependency hoặc cấu hình native, build lại bằng `run:android`/`run:ios`. `npm run build` của repo xuất bundle; không tạo APK/IPA cài được.

## E. Kiểm luồng app

1. Mở danh mục, chọn **Điện nước → Dịch vụ điện nước**.
2. Thấy kỹ năng **Sửa điện dân dụng** từ seed local.
3. Quay lại bằng nút app; Android kiểm thêm nút Back của hệ điều hành.
4. Dừng API ở Terminal A. Tạo lần tải mới bằng đổi lựa chọn hoặc mở lại màn; danh sách đã tải không tự mất ngay khi API dừng.
5. Chờ timeout tối đa khoảng 10 giây, thấy thông báo lỗi/thử lại.
6. Chạy lại `npm run api`, bấm Thử lại và thấy dữ liệu.

Nếu DB local đã được người dùng chỉnh khác seed, đối chiếu dữ liệu thay vì reset DB để làm khớp ví dụ.

## F. Điện thoại thật — nhánh sau máy ảo

`127.0.0.1` trên điện thoại là chính điện thoại, không phải Mac. Với kết nối Wi-Fi, cần cùng mạng, API `HOST=0.0.0.0`, Metro dùng `--lan`, và `EXPO_PUBLIC_API_URL` trỏ IP LAN thật của Mac. Không dùng script hiện có `npm run mobile` vì script đang ép `--localhost`.

Nhờ Codex cấu hình theo thiết bị cụ thể; Android USB có thể dùng `adb reverse`, iPhone thật có thêm yêu cầu signing/trust. Expo tunnel cho Metro không tự làm API cổng 3100 truy cập được. Không mở cổng router hoặc deploy API công khai để thử local.

Kết thúc buổi: dừng API/Metro ở đúng tab, rồi từ thư mục gốc chạy `npm run db:stop` nếu không dùng DB nữa. Lệnh này giữ dữ liệu; không dùng `docker compose down -v`.
