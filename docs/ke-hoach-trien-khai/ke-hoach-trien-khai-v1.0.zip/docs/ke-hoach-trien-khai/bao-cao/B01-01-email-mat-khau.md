# B01-01 — Email/mật khẩu và phiên: đọc code theo một lần đăng nhập

DOC-088 · v1.0 · 01/10/2026 · DELIVERY-01. Báo cáo hồi cứu cho commit [`50d184a`](https://github.com/anhthaingd/dich-vu-quanh-ban/commit/50d184a). [Checklist](../01-checklist.md).

## Kết quả và phạm vi

Người dùng đăng ký/đăng nhập bằng email và mật khẩu, thấy trạng thái email chưa xác minh, đóng/mở app vẫn khôi phục phiên, đăng xuất thu hồi phiên server. Cấu hình local đã được chủ dự án duyệt trong hội thoại: mật khẩu 15–128 ký tự, access 15 phút, phiên tuyệt đối tối đa 30 ngày. Không báo toàn B01 hoàn tất: chưa OTP/email thật, reset/identity/recovery/deletion, membership hay MFA admin đầy đủ.

## Luồng chính

```mermaid
sequenceDiagram
  participant U as Người dùng
  participant S as AccountScreen
  participant M as AuthSession
  participant A as auth-api/requestJson
  participant B as AuthController/AuthService
  participant D as PostgreSQL
  participant K as SecureStore
  U->>S: Nhập email/mật khẩu, bấm Đăng nhập
  S->>M: login(credentials)
  M->>M: busy=true, chặn thao tác chồng
  M->>A: POST /auth/login
  A->>B: JSON + correlation ID
  B->>D: Đọc identity, kiểm hash, khóa user và tạo session
  B-->>A: access + refresh + expires_at + user
  A-->>M: Session đã kiểm shape
  M->>K: Lưu refresh token
  K-->>M: Thành công
  M->>M: phase=authenticated, user; busy=false
  M-->>S: Subscriber nhận snapshot mới
  S-->>U: Tài khoản, email chưa xác minh
```

## Thứ tự đọc file

| Bước | File / hàm thật | Bạn cần hiểu |
|---|---|---|
| 1 | [App.tsx](../../../apps/mobile/src/app/App.tsx) | Tạo một AuthSession từ AuthApi + TokenStorage, nối vào provider |
| 2 | [AuthProvider.tsx](../../../apps/mobile/src/app/providers/AuthProvider.tsx) | `restore` khi mount; `verify` khi AppState active; useSyncExternalStore đọc snapshot |
| 3 | [AccountScreen.tsx](../../../apps/mobile/src/features/auth/screens/AccountScreen.tsx), `submit` | Giữ form local; gọi register/login, đóng keyboard, xóa password sau submit/rời màn; nút disabled khi chưa đủ/busy |
| 4 | [auth-session.ts](../../../apps/mobile/src/features/auth/state/auth-session.ts), `run`, `accept` | Quản lý busy/error/phase; chỉ thông báo login thành công sau khi lưu phiên an toàn |
| 5 | [auth-api.ts](../../../apps/mobile/src/features/auth/api/auth-api.ts) | Route, body, Bearer, kiểm Session/Me/Ack; không giữ UI state |
| 6 | [request.ts](../../../apps/mobile/src/lib/http/request.ts) | HTTP timeout/cancel, mã lỗi và correlation; không tự retry mutation |
| 7 | [auth.controller.ts](../../../services/api/src/modules/auth/auth.controller.ts), [auth.input.ts](../../../services/api/src/modules/auth/auth.input.ts) | Route, rate limit local, validate/chuẩn hóa email/password; từ chối trường quyền do client thêm |
| 8 | [auth.service.ts](../../../services/api/src/modules/auth/auth.service.ts), `login`, `issue`, `transaction` | Kiểm user active, tạo session trong DB, ký access token, return profile đúng phạm vi |
| 9 | [password.ts](../../../services/api/src/modules/auth/password.ts) | scrypt + salt ngẫu nhiên; timing-safe compare; giới hạn việc hash đồng thời |
| 10 | [002_accounts.sql](../../../services/api/migrations/002_accounts.sql) | users, identities, sessions; unique identity/refresh hash; chỉ mục user/family |
| 11 | [token-storage.ts](../../../apps/mobile/src/features/auth/state/token-storage.ts) | Native SecureStore chỉ lưu refresh; web preview chỉ memory, không localStorage |

## Bốn nhánh cần lần theo ngoài happy path

**Mở lại app:** provider gọi restore → đọc refresh trong SecureStore → `/auth/refresh` → server khóa user, thu hồi token cũ, tạo session mới cùng family/mốc hết hạn → lưu refresh mới → render profile. Refresh không kéo dài 30 ngày. Access token chỉ giữ trong memory.

**Refresh cũ bị dùng lại:** server phát hiện session revoked → thu hồi toàn family → commit revocation rồi mới trả 401. Nếu ném lỗi bên trong transaction làm rollback, việc thu hồi sẽ mất; test integration có kiểm tình huống này và hai refresh đồng thời.

**Đăng xuất:** app gọi server trước → server thu hồi family → app xóa SecureStore và user state. Mất mạng thì giữ phiên/error để thử lại, không tuyên bố server đã logout. Mỗi lần authenticate đều kiểm session DB, nên token ký còn hạn vẫn bị từ chối sau revoke.

**Lưu SecureStore thất bại:** `accept` thử logout phiên vừa cấp và không hiển thị login thành công. Nếu logout bù cũng mất mạng, expiry server là giới hạn còn lại; không khẳng định phiên server đã bị thu hồi trong nhánh này.

## Dữ liệu và giới hạn bảo mật

| Nơi | Dữ liệu giữ |
|---|---|
| Form | Password trong memory khi đang nhập; không lưu lâu dài |
| Snapshot UI | phase/user/busy/error; không đưa token vào snapshot |
| AuthSession | Access/refresh ở memory; không dùng state hiển thị để cấp quyền |
| SecureStore | Refresh token native; test runner dùng namespace riêng |
| DB identities | Password hash có salt; verified_at vẫn null |
| DB sessions | SHA-256 refresh hash, family, expires_at, revoked_at; không lưu refresh thô |
| Log | Event/route/status/correlation; test canary xác nhận không lộ email/password/token |

Rate limit hiện ở một process local, chưa là limiter phân tán production. Profile trả mảng partner/admin rỗng và cờ verified false cho lát này; không phải toàn bộ authorization đã hoàn thiện. `locale` chỉ `vi`; lỗi UI còn viết trực tiếp trong state, là việc I18N-01 cần xử lý.

## Thay đổi và cách thử

Thêm auth module, migration 002, AuthProvider/AccountScreen/AuthSession, SecureStore, dependency `jose`, route Account và tests. `AUTH_SECRET` riêng trong env ignored bật auth module; `.env.example` chỉ là ví dụ local. API health/catalog vẫn chạy độc lập khi chưa bật auth.

Mở app → Tài khoản → Đăng ký → tên/email test/mật khẩu 15–128 ký tự → thấy “Email chưa xác minh”. Đóng/mở app rồi vào Tài khoản để kiểm restore. Logout → login sai → kiểm lỗi, email còn/password được xóa → thử lại đúng. Không dùng tài khoản thật khi thử test DB.

Trên iOS, đăng ký đang tắt gợi ý tạo mật khẩu vì input view new-password đã gây lỗi trong build iOS 27 được thử; login vẫn giữ AutoFill. Hỗ trợ nút Xong trên bàn phím. Maestro đóng hộp thoại Save Password; fallback tọa độ đã kiểm trên iPhone 18 Pro, cần rà lại khi đổi simulator/runtime. Không coi bản vá này là đã kiểm mọi thiết bị iOS.

## Kiểm thử và bằng chứng

| Lớp | Kết quả cuối của lát code | Nguồn |
|---|---|---|
| Mobile | 65 tests đạt; coverage gate core lines 100%, app lines khoảng 98.73% | `npm run test:coverage -w apps/mobile`; [state tests](../../../apps/mobile/src/features/auth/state/auth-session.test.ts), [screen tests](../../../apps/mobile/src/features/auth/screens/AccountScreen.test.tsx) |
| API/DB | 30 tests đạt; hash/revocation/concurrency/TTL 15 phút/30 ngày, contract và safe logs | `npm run test:coverage -w services/api`; [auth integration](../../../services/api/test/integration/auth.test.ts) |
| Web | 3 tests đạt, gồm auth và catalog với DB thật | `npm run test:e2e`; [auth.spec.mjs](../../../tests/e2e/web/auth.spec.mjs) |
| Native | Android PASS `2026-09-30T15:14:23.889Z`; iOS PASS `2026-09-30T15:12:09.013Z` | `test-results/native/{android,ios}/auth/result.json`; [auth.yaml](../../../tests/e2e/native/auth.yaml) |
| Tooling/build | 3 tooling tests; typecheck/lint/build/native-config đạt | Scripts hiện hành ở root package.json; log local của phiên triển khai |
| CI | 3 jobs đạt tại đúng `50d184a`, kiểm lại ngày 01/10 | [Quality](https://github.com/anhthaingd/dich-vu-quanh-ban/actions/runs/36810424485) |

Native kiểm trên Android API 36 và iPhone 18 Pro/iOS 27 simulator; flow gồm register → cold-start restore → logout → wrong-login/retry → logout. Schema test đã xóa; API 3100 và Metro 8081/8082 được giữ, Metro test 8083/8084 đã dừng sau phiên kiểm. Đây là bằng chứng của phiên triển khai, không phải đảm bảo các process luôn chạy khi đọc báo cáo.

Các con số trên là toàn suite tại commit, không phải 65/30 ca đều riêng auth. Báo cáo được viết từ code/artifact đã có; không chạy lại app trong đợt viết tài liệu. CI artifact có thời hạn giữ; local artifact bị ignore, có thể cần chạy lại theo [lệnh](../02-quy-trinh-va-cau-truc.md).

## Bài đọc code để tự kiểm hiểu

1. Theo `AccountScreen.submit` → `AuthSession.login` → `accept`: tại sao `authenticated` được đặt sau SecureStore write?
2. Theo `AuthService.refresh`: tại sao nhánh replay trả null khỏi transaction rồi mới ném 401?
3. Theo `verify`: tại sao đang anonymous phải trả về trước khi lấy khóa busy? Test hồi quy chứng minh foreground check không nuốt thao tác login.
4. Thử local nhập sai mật khẩu: quan sát phase/busy/error và requestId; không thêm console.log(credentials). Tìm chỗ dịch thông báo hiện tại, rồi đối chiếu kế hoạch đổi sang mã lỗi ở I18N-01.

Bước sau là i18n rồi các lát B01 còn lại trong checklist. Email chưa xác minh không được nâng thành verified chỉ để đi tiếp tới thuê dịch vụ.
