# B00-01 — Nền tảng và luồng danh mục: đọc code từ UI tới DB

DOC-087 · v1.0 · 01/10/2026 · DELIVERY-01. Báo cáo hồi cứu, đối chiếu `41579b5` và kiểm hồi quy ở `50d184a`. [Checklist](../01-checklist.md).

## Kết quả và giới hạn

Đã có npm workspace Expo/NestJS, PostgreSQL/PostGIS, danh mục đọc thật, theme/UI chung, native stack, log/test và CI. Người dùng đi ngành → nhóm → kỹ năng, thấy tải/rỗng/lỗi và thử lại. Đây là lát nền tảng, không phải toàn bộ nguồn cung B02 hay shell/tab sản phẩm UI-16. Những folder partner/jobs/admin giữ chỗ không có chức năng thật.

## Lần theo một thao tác: bấm ngành Điện nước

```mermaid
sequenceDiagram
  participant U as Người dùng
  participant C as ActionCard/CatalogScreen
  participant N as Native stack
  participant A as Catalog API client
  participant S as Controller/Service
  participant D as PostgreSQL
  U->>C: Bấm ngành
  C->>N: navigate(categoryId, title)
  N->>C: Màn mới focus
  C->>A: categories(id), skills(id), AbortSignal
  A->>S: GET /v1/categories và /v1/skills
  S->>D: Lọc cây active + cursor + LIMIT
  D-->>S: Rows
  S-->>A: items, next_cursor
  A-->>C: Danh sách đã kiểm response
  C-->>U: ready hoặc error/retry
```

| Thứ tự đọc | File / hàm | Input → output; trách nhiệm |
|---|---|---|
| 1 | [App.tsx](../../../apps/mobile/src/app/App.tsx) | Khởi tạo client từ API URL; nối providers/navigation |
| 2 | [AppProviders.tsx](../../../apps/mobile/src/app/providers/AppProviders.tsx) | Cung cấp CatalogApi qua context; safe area/status bar |
| 3 | [AppNavigator.tsx](../../../apps/mobile/src/app/navigation/AppNavigator.tsx) | Stack Home/Category/Account; ID route giúp biết đang xem nhóm nào |
| 4 | [Card.tsx](../../../apps/mobile/src/components/ui/Card.tsx), `ActionCard` | Nhận title/onPress, chỉ vẽ và gọi callback; không biết DB |
| 5 | [CatalogScreen.tsx](../../../apps/mobile/src/features/catalog/screens/CatalogScreen.tsx), `useFocusEffect` | ID → gọi hai API → loading/ready/error; cleanup abort khi blur/unmount |
| 6 | [catalog-api.ts](../../../apps/mobile/src/features/catalog/api/catalog-api.ts), `all` | Theo next_cursor, kiểm shape và cursor lặp; trả danh sách đầy đủ |
| 7 | [request.ts](../../../apps/mobile/src/lib/http/request.ts), `requestJson` | Fetch + timeout/cancel + correlation; lỗi có mã; không log body nhạy cảm |
| 8 | [catalog.controller.ts](../../../services/api/src/modules/catalog/catalog.controller.ts), [catalog.query.ts](../../../services/api/src/modules/catalog/catalog.query.ts) | Nhận HTTP, kiểm UUID/limit/cursor rồi gọi service |
| 9 | [catalog.service.ts](../../../services/api/src/modules/catalog/catalog.service.ts), `list` | SQL kiểm toàn chuỗi cha đang active, phân trang ổn định, trả cursor ký |
| 10 | [001_catalog.sql](../../../services/api/migrations/001_catalog.sql) | categories, skills, skill_categories, index và chống vòng cây |

**Đường lỗi:** API hoặc mạng lỗi → `ApiError` → screen chuyển `error` → người dùng bấm Thử lại → tăng `retry` → effect tải lại. Nếu rời màn khi đang tải, AbortController ngăn kết quả cũ cập nhật màn đã rời. Native stack vẫn giữ màn cũ trong bộ nhớ nên chỉ cleanup khi unmount là chưa đủ.

## Dữ liệu và cấu trúc

`categories` là cây dùng ID, `skills` nối nhiều category qua bảng liên kết. `translations` của category hiện để mở rộng; UI/API vẫn dùng `name_vi`, chưa có i18n. Không dùng tên dịch làm khóa dữ liệu. Hiện SQL ở service vì phạm vi còn nhỏ; chưa cần repository wrapper rỗng.

Source thay đổi chính ở theme, components/ui, navigation/providers, catalog và test runner. Native CNG sinh binary từ cấu hình; native generated không phải code cần review trong Git. Log phương án A đã có sanitizer và requestId; xem [runbook](../../implementation/logging-testing.md) để vận hành, không dùng trạng thái native cũ trong runbook làm tiến độ hiện hành.

## Bằng chứng và cách thử

- [CI 41579b5](https://github.com/anhthaingd/dich-vu-quanh-ban/actions/runs/36729018889): 3 jobs đạt. [CI 50d184a](https://github.com/anhthaingd/dich-vu-quanh-ban/actions/runs/36810424485): 3 jobs đạt sau thêm auth.
- Kiểm hồi quy local native: Android `2026-09-30T15:08:01.800Z`, iOS `2026-09-30T15:13:22.612Z`; đều PASS trong `test-results/native/{android,ios}/result.json`. Môi trường DVQB_API_36 và iPhone 18 Pro/iOS 27; không là test thiết bị thật.
- Flow [catalog.yaml](../../../tests/e2e/native/catalog.yaml): back/resume, lỗi→retry, rỗng→khôi phục; API và schema PostgreSQL test riêng, đã dọn schema.
- [catalog.test.ts](../../../services/api/test/integration/catalog.test.ts) kiểm HTTP/DB; [CatalogScreen.test.tsx](../../../apps/mobile/src/features/catalog/screens/CatalogScreen.test.tsx) kiểm hành vi screen; [catalog.spec.mjs](../../../tests/e2e/web/catalog.spec.mjs) kiểm web với API/DB thật.
- Tái hiện: chạy API/Metro theo [hướng dẫn](../../huong-dan-mobile/04-chay-app.md), bấm một ngành rồi Back; test tự động dùng `DEVICE_ID=... npm run test:native -- android catalog` hoặc `ios catalog`. Flow lỗi/rỗng chỉ điều khiển schema test, không sửa DB làm việc.

Bản báo cáo này đọc lại code và artifact đã có ngày 01/10, không tuyên bố đã chạy lại bộ test trong đợt viết tài liệu.

## Tự học từ code này

1. Vì sao Card nhận callback thay vì tự gọi API? Để UI dùng lại được cho nhiều feature; screen sở hữu ý nghĩa hành động.
2. Vì sao query phải lọc cha active? Tắt một ngành phải ẩn cả nhánh, không chỉ hàng cha; xem CTE `visible`.
3. Vì sao route giữ ID? ID ổn định qua đổi tên/ngôn ngữ. `title` hiện là chuỗi VI chụp lúc navigate, cần sửa ở I18N-02 để đổi tiếng không giữ tiêu đề cũ.

Bài thử local an toàn: mở Network/log có requestId, vào một ngành rồi quay lại nhanh; đọc effect cleanup và đối chiếu request cancelled. Không thêm log toàn bộ response/token. Bước sau: I18N và shell sản phẩm theo checklist; không đánh dấu toàn B00/B02 hoàn tất.
