# Mẫu báo cáo chức năng và hướng dẫn đọc code

DOC-086 · v1.0 · 01/10/2026 · DELIVERY-01. Đây là mẫu chưa điền, không là bằng chứng đã triển khai. [Mục lục](../README.md).

Tạo file `<MA-LAT>-<ten-chuc-nang>.md` riêng cho mỗi lát bàn giao lớn. Mọi mục bên dưới phải có nội dung thực hoặc “không áp dụng” kèm lý do. Không chép số test, đường dẫn, tỷ lệ coverage từ lần chạy trước.

## 1. Thông tin và kết quả

Mã checklist; ngày; người thực hiện; commit/baseline hoặc working tree; nguồn spec và QA/operationId. Nêu người dùng làm được gì trước/sau, phần ngoài phạm vi, trạng thái local/CI/UAT riêng.

## 2. Demo theo góc nhìn người dùng

Các bước chuẩn bị app/API/DB, tài khoản test, thao tác happy path và một lỗi có recovery. Không ghi secret thật. Nêu kết quả mong đợi và kết quả đã quan sát; liên kết ảnh/video khi chúng giúp đánh giá.

## 3. Luồng code theo một thao tác thật

Sơ đồ Mermaid từ sự kiện bấm đến DB rồi quay về UI. Viết bảng có **thứ tự đọc → file thật và hàm → input → output → lý do thuộc lớp này**. Mỗi file phải có link tương đối mở được trong repo. Theo cả đường thành công và đường lỗi; nêu async/transaction/cancel/race khi có.

## 4. Dữ liệu, trạng thái và quyền

Bảng/field/migration, request/response đã dùng, ai có quyền gì, dữ liệu nào nằm memory/SecureStore/DB. Giải thích invariant, retry/idempotency, logout/thu hồi, offline và dữ liệu nhạy cảm. Không chỉ liệt kê tên thư viện.

## 5. Danh sách thay đổi

File thêm/sửa/xóa, trách nhiệm và ảnh hưởng tương thích; dependency/config mới và lý do. Nếu thay spec: nêu quyết định được duyệt và nguồn đã đồng bộ. Nếu code theo spec: ghi không thay spec, chỉ cập nhật báo cáo/checklist.

## 6. Kiểm thử và bằng chứng

| Lớp kiểm | Lệnh/kịch bản | Ngày + môi trường | Kết quả | Bằng chứng/giới hạn |
|---|---|---|---|---|
| Unit | Điền khi chạy | | | |
| API/DB + quyền | Điền khi chạy | | | |
| Native Android/iOS | Ghi từng nền tảng | | | |
| Web/CI | Phân biệt web preview và sản phẩm web | | | |
| Build/type/lint | Điền khi chạy | | | |

Test giả lập pass không thay tích hợp thật; native-config pass không thay test UI; export bundle không thay cài binary; CI chưa chạy phải ghi rõ. Artifact hết hạn/không track Git cần đường tái hiện.

## 7. Hướng dẫn học code

Giải thích 3–5 khái niệm trực tiếp từ code của lát. Đặt 2–3 câu hỏi cụ thể (ví dụ: bỏ kiểm version sẽ gây lỗi gì?) và chỉ file/hàm để tự lần theo. Thêm một bài thử nhỏ an toàn ở local để quan sát state/log; không cần viết lại chức năng.

## 8. Tồn đọng và bước sau

Bug/giới hạn/pending, tác động, mã nhiệm vụ xử lý tiếp; không ghi “hoàn tất Bxx” khi mới xong một lát. Link dòng checklist, báo cáo trước/sau và phần cần chủ dự án quyết định. Commit/push/deploy là trạng thái riêng, không suy ra từ kết quả test.
