# Kế hoạch triển khai và học code

DOC-082 · v1.0 · 01/10/2026 · DELIVERY-01. Đối chiếu code tại commit `50d184a`.

Đây là điểm vào công việc cho các phiên Codex tiếp theo. Kế hoạch phân rã thiết kế sẵn có thành các lát triển khai có thể kiểm chứng; không thay SRS, hợp đồng API hoặc quyết định nghiệp vụ. Những nhiệm vụ chưa làm là kế hoạch, không phải phê duyệt nhà cung cấp, chi phí hay production.

## Mở theo thứ tự

1. [Checklist chức năng](01-checklist.md): đang ở đâu, đã kiểm gì, phần còn thiếu, bước kế tiếp.
2. [Quy trình và cấu trúc code](02-quy-trinh-va-cau-truc.md): mỗi lớp chịu trách nhiệm gì; cách thực hiện một nhiệm vụ.
3. [Thứ tự triển khai](03-thu-tu-trien-khai.md): đầu vào, bước làm, đường dẫn dự kiến, điều kiện chuyển bước.
4. [Mẫu báo cáo](bao-cao/MAU-BAO-CAO.md): tạo báo cáo riêng sau mỗi chức năng lớn/lát bàn giao.
5. Đọc hai báo cáo thực tế bên dưới để học code đã có.

## Báo cáo đã có

| Lát bàn giao | Báo cáo | Phạm vi thực tế |
|---|---|---|
| Nền tảng + danh mục | [B00-01](bao-cao/B00-01-nen-tang-danh-muc.md) | App/API/DB, UI chung, navigation, log/test; không đóng toàn bộ B00 |
| Tài khoản email/mật khẩu | [B01-01](bao-cao/B01-01-email-mat-khau.md) | Đăng ký/đăng nhập, refresh/logout local; không đóng toàn bộ B01 |

Báo cáo con tiếp theo dùng mã `Bxx-nn` hoặc `I18N-nn`; thêm vào bảng này và liên kết dòng checklist. Không sửa báo cáo cũ để biến kết quả của commit cũ thành bằng chứng cho commit mới. Nếu sửa báo cáo, giữ ngày/commit và ghi phần đính chính.

## Hiện trạng và công việc kế tiếp

- Đã có danh mục DB thật và lát email/mật khẩu local, UI dùng chung, native navigation, log/test.
- CI của `50d184a` đã đạt: [Quality 36810424485](https://github.com/anhthaingd/dich-vu-quanh-ban/actions/runs/36810424485). Native được kiểm riêng trên máy phát triển, không chạy trong CI Ubuntu này.
- i18n chưa triển khai. `AuthSession` còn giữ chuỗi tiếng Việt; API `locale` hiện chỉ nhận `vi`.
- **Lát làm tiếp đề xuất: I18N-01 → I18N-02**, trước khi thêm màn nghiệp vụ. I18N-03/04 có tác động contract/dữ liệu cần chốt phạm vi trước khi sửa spec.
- Chưa có nghiệm thu UAT toàn app, tài khoản/partner/công việc/chat/tài chính đầy đủ hoặc phát hành.

## Nguồn chuẩn cần tra

- [AGENTS.md](../../AGENTS.md): quy tắc làm việc mới nhất, bao gồm báo cáo sau chức năng lớn.
- [Backlog B00–B11](../technical-design/04-backlog.md), [API](../technical-design/openapi.json), [dữ liệu](../technical-design/01-data-design.md), [QA](../technical-design/03-qa-plan.md), [RTM](../technical-design/rtm.json).
- [Phạm vi UX](../../ui-ux/specs/ux-scope-current.md), [design system](../../ui-ux/specs/design-system.md), [rà soát luồng](../../ui-ux/specs/flow-review.md).
- [Sổ quản lý](../project-control/So-quan-ly-tai-lieu.xlsx) quản lý nguồn/ảnh hưởng/quyết định. Checklist này quản lý tiến độ code; hai vai trò khác nhau.

Các mô tả “native chưa chạy”, “B01 chưa triển khai” trong tài liệu mốc 28–29/09 là lịch sử. Dùng checklist và báo cáo gắn commit ở bộ này để biết tiến độ code hiện tại. Quy tắc đồng bộ toàn bộ tài liệu sau mỗi thay đổi code trong tài liệu cũ đã được thay bởi AGENTS.md ngày 30/09 và DELIVERY-01 ngày 01/10. Không dùng báo cáo triển khai để âm thầm đổi nghiệp vụ.

## Cách giữ tiến độ không bị quên

Mỗi phiên: đọc AGENTS → checklist → nhiệm vụ đang làm → spec liên quan → code thực tế. Chọn một lát đang hoạt động. Kết thúc lát: kiểm thử → tự review → viết báo cáo giải thích code → cập nhật checklist và mục lục báo cáo → bàn giao cho chủ dự án. Chỉ commit/push khi yêu cầu giao việc có cho phép; production/tiền thật luôn là quyết định riêng.

## Phạm vi lưu trữ bộ tài liệu

**Bàn giao 01/10/2026:** nguồn local và đăng ký sổ local đã kiểm. Chưa đồng bộ Drive: automatic approval review từ chối upload ZIP vì cần chủ dự án cho phép rõ payload tài liệu/AGENTS. Sổ trên Drive giữ nguyên; chờ cho phép tải gói mới và cập nhật sổ cùng ID. Không có commit/push cho đợt tài liệu này.

Markdown trong thư mục này là nguồn chính. Gói `ke-hoach-trien-khai-v1.0.zip` chứa 7 Markdown của bộ mới cùng snapshot README/AGENTS ở gốc repo; đây là bản xuất theo phiên bản, không thay nguồn Markdown. Không có viewer HTML/localhost riêng cho bộ mới; không sửa các ZIP kỹ thuật/UI cũ; chúng chưa có bộ mới và README trong các gói cũ chỉ phản ánh mốc cũ. Gói mới là nguồn phân phối hiện hành của README/AGENTS và kế hoạch triển khai, không thay thiết kế kỹ thuật bên trong gói cũ. Các bản Drive là bản phân phối, giữ cùng ID khi cập nhật. Chi tiết đăng ký và kiểm chứng nằm trong sổ quản lý.
