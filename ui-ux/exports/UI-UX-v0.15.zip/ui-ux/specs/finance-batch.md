# DOC-060 · Ví, ngân hàng và quyền hiện hành — UI-17

React v0.11 · 26/09/2026 · Bản thiết kế để review, chưa triển khai sản phẩm.

## Mở giao diện
- Storybook: wallet-mobile, partner-wallet, company-wallet (nhóm Dịch vụ quanh bạn / Thử giao diện).
- Ví ở thanh điều hướng partner; chọn Nạp tiền, Rút tiền, Ngân hàng nhận tiền hoặc Lịch sử ví.
- Avatar → Đội ngũ doanh nghiệp → Quyền truy cập: xem quyền thực tế của từng thành viên đang hoạt động.

## Luồng ví
Ví → Nạp/Rút → nhập số tiền → gửi yêu cầu → lịch sử → mở chi tiết.
Rút yêu cầu xác nhận ngân hàng; tiền giữ ngay, không được dùng hạn mức âm để rút. Nạp chờ duyệt không cộng số dư. Lệnh rút lưu bản chụp ngân hàng tại thời điểm tạo; đổi hồ sơ sau này không đổi lệnh cũ.
Lịch sử lọc Tất cả / Nạp / Rút / Phí–point, xem chi tiết thời gian, số tiền, ngân hàng hoặc phí và point công việc. Tiền trả trực tiếp không xuất hiện như tiền đi vào ví.

## Ngân hàng
Ví → Ngân hàng → nhập đề nghị mới + lý do + xác thực mẫu → Chờ admin.
Ngân hàng đang dùng giữ nguyên. Có thể hủy đề nghị. Chặn thay đổi khi đang có lệnh rút giữ tiền. Chỉ một tài khoản nhận đang hoạt động. Quy tắc này áp dụng theo baseline DOC-007, không đổi nghiệp vụ.

## Quyền
Hiển thị quyền hiện hành của chủ/quản lý và nhân viên; quản lý có thể kiêm thực hiện, không cần điều phối riêng. Không cấp quyền đọc chat cá nhân. Đây là màn giải thích quyền thực tế, KHÔNG phải trình cấp quyền tùy chỉnh.

## Kiểm chứng
- 35 kiểm tra logic đạt: gồm giữ ngân hàng cũ, chặn đổi khi rút đang giữ, mã mẫu sai, chống đề nghị trùng, rút vượt khả dụng/ngân hàng chưa xác minh.
- Build Vite và Storybook đạt; 42 stories.
- Browser: rút 100.000đ từ 500.000đ → khả dụng rút 400.000đ, giữ 100.000đ; đổi ngân hàng bị chặn. Partner khác đề nghị ACB → ngân hàng đang dùng vẫn Vietcombank.
- Browser: Avatar → Đội ngũ → Quyền truy cập hiển thị đúng 3 người, quản lý và nhân viên khác quyền. Mobile 390px và desktop 1440px được kiểm tra; không tràn ngang.

## Phần còn lại, không coi đã hoàn tất
- Cấp/sửa quyền tùy chỉnh và mô phỏng cấp quyền tài chính chưa chuyển sang React.
- Admin duyệt/từ chối nạp, rút, ngân hàng; ngân hàng lần đầu và kết quả từ chối chưa có trong React, thuộc phần tiếp nối.
- Không có OTP, ngân hàng thật, thanh toán thật, backend, lưu bền hoặc xử lý đồng thời. Dữ liệu mất khi tải lại.
- Chuyển chủ/đóng doanh nghiệp, bút toán ngoại lệ vẫn pending theo phạm vi đã chốt.

## Đồng bộ
DOC-050, DOC-052, DOC-053, DOC-057, PLAN-006 và README trỏ tới phần này. UI-UX-v0.15.zip chứa nguồn và bản build. Sổ quản lý v1.23 cùng Drive ID. BRD/FR/NFR/SRS/ERD/API và wireframe nghiệp vụ không thay đổi vì chỉ chuyển một phần nghiệp vụ đã chốt vào thiết kế React; các phần chưa chuyển được ghi rõ, không tự mở lại pending.
