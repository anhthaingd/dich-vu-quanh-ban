export const initialBank=owner=>({bank:'Vietcombank',number:'0000002468',owner:owner.toUpperCase(),status:'verified',proposal:null});
export function proposeBank(current,data,pendingWithdrawals){
 if(pendingWithdrawals)return {error:'Cần xử lý xong yêu cầu rút đang giữ tiền trước khi đổi ngân hàng.'};
 if(current.proposal)return {error:'Bạn đang có đề nghị chờ duyệt.'};
 if(!data.bank?.trim()||!/^\d{6,20}$/.test(data.number)||!data.owner?.trim()||!data.reason?.trim())return {error:'Điền ngân hàng, số tài khoản 6–20 chữ số, tên chủ tài khoản và lý do.'};
 if(data.code!=='123456')return {error:'Mã xác thực mẫu chưa đúng. Dùng 123456 để thử.'};
 return {bank:{...current,proposal:{bank:data.bank.trim(),number:data.number,owner:data.owner.trim().toUpperCase(),reason:data.reason.trim(),status:'pending'}}};
}
export function validateRequest(type,amount,available,bank){
 if(!Number.isSafeInteger(amount)||amount<=0)return 'Nhập số tiền nguyên lớn hơn 0.';
 if(type==='withdraw'&&bank.status!=='verified')return 'Ngân hàng cần được xác minh trước khi rút.';
 if(type==='withdraw'&&amount>available)return 'Số tiền vượt khoản có thể rút. Hạn mức âm không dùng để rút.';
 return '';
}
