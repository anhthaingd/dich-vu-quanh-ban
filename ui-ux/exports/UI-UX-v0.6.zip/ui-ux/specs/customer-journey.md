# Luồng khách hàng React v0.5

DOC-056 · 23/09/2026 · UI-05 cho phép làm gộp design system và luồng khách hàng. Bản này để review thiết kế, không kết nối dịch vụ hoặc tiền thật.

```mermaid
flowchart LR
 A[Tìm dịch vụ / bản đồ] --> B[Hồ sơ]
 B <--> C[Chat trước thuê]
 B --> D[Chọn nơi làm và thời gian]
 C --> D
 D --> E[Chờ partner nhận]
 E --> F[Theo dõi công việc]
 F --> G[Ảnh kết quả và hóa đơn]
 G --> H{Khách kiểm tra}
 H -->|Yêu cầu sửa| G
 H -->|Chọn point và xác nhận| I[Khóa hóa đơn]
 I --> J[Khách trả trực tiếp / báo đã trả]
 I --> K[Thợ xác nhận nhận tiền]
 J --> L{Đủ hai xác nhận}
 K --> L
 L --> M[Hoàn tất và đánh giá]
 M --> D
```

Thứ tự khách báo trả và thợ báo nhận có thể đảo nhau. Quyết toán/thưởng ở xác nhận nhận tiền; đánh giá cần cả hai dấu. Thuê lại giữ chat cùng partner trong phiên.

## Cách thử

1. Mở `http://127.0.0.1:5178/` hoặc story Desktop/Mobile hiện có.
2. Chọn hồ sơ → Thuê dịch vụ, hoặc Nhắn tin → Thuê dịch vụ này.
3. Nhập địa chỉ, chọn Làm ngay/Hẹn trước → Gửi yêu cầu thuê.
4. Bấm **Xem phía partner**, hoặc dùng thanh chọn vai trò. Nhận việc, phân công nếu là cửa hàng, chọn ảnh kết quả và gửi hóa đơn. Xem hướng dẫn chi tiết trong DOC-057.
5. Kiểm hóa đơn, dùng point nếu muốn. Có thể yêu cầu sửa; ví partner dùng để kiểm điều kiện giữ phí. Xác nhận hóa đơn rồi báo thanh toán.
6. Chuyển sang người thực hiện, xác nhận nhận tiền → phía khách đánh giá → thuê lại. Danh sách Công việc và Tin nhắn dùng được.

## Nghiệp vụ giữ nguyên

- Không bắt buộc chat trước khi thuê. Tin nhận việc được thêm vào phòng chat của cặp người dùng hiện có.
- Không tự hết hạn công việc; không có nút bắt đầu làm. Hóa đơn khóa không sửa nội dung/point.
- Vật tư và công tách riêng. Phí = floor(công × 10%). Thưởng = floor(công × tiền trả trực tiếp / (50 × tổng)); tổng 0 thì thưởng 0, theo prototype nghiệp vụ hiện hành.
- Hóa đơn mẫu: công 200.000đ, vật tư 100.000đ. Dùng 80.000 point → trả trực tiếp 220.000đ, phí 20.000đ, thưởng 2.933 point. Toàn point không có thưởng mới.
- Khách thiếu điều kiện xác nhận chỉ thấy thông báo phù hợp, không thấy ví/nợ partner. Point đã giữ không dùng lại ở công việc khác.
- Banner/quảng cáo/voucher vẫn ngoài phase đầu. Q02 vẫn cần giải quyết trước tiền thật.

## Phạm vi bản thử và phần chưa được chuyển sang UI mới

Luồng chính đã nối xuyên suốt, kèm chờ/từ chối/yêu cầu sửa/thiếu số dư/mất kết nối. Tài khoản dùng mẫu; dữ liệu lưu trong bộ nhớ trang, tải lại sẽ mất. Partner có màn thao tác riêng, dùng chung dữ liệu với khách. Thợ chọn ảnh và nhập số tiền, hóa đơn sửa tăng phiên bản; mọi thao tác chỉ mô phỏng trong bộ nhớ, không phải giao dịch thật.

Bản đồ/ảnh là minh họa; tìm kiếm vẫn cố định Cầu Giấy. Chưa có đăng nhập thật, gọi thật, nhắc lịch thật, định vị, lưu chat/backend hoặc chuyển tiền. Ảnh đánh giá chưa có trong UI mới. Đổi lịch/dừng việc/báo cáo hỗ trợ và các ngoại lệ khác tiếp tục tra prototype nghiệp vụ cổng 8765; bản React v0.3 chưa thay thế toàn bộ prototype đó. Nhóm partner/doanh nghiệp đã thêm ở v0.4, xem DOC-057; nhóm admin React và các màn phụ vẫn tiếp tục sau.

## Kiểm chứng lịch sử v0.3 ngày 23/09/2026

- Vite và Storybook build thành công. 14 stories gồm nền tảng, chờ nhận, hóa đơn, thanh toán, đánh giá và mobile hóa đơn.
- 8 bài kiểm tra logic: tiền/point, toàn point/0đ, hai thứ tự xác nhận, không đánh giá sớm, lặp nhận tiền không cộng lần hai, yêu cầu sửa/thay phiên bản, khóa không sửa, số point sai và chưa nhận việc không lập hóa đơn.
- Browser: từ hồ sơ gửi thuê → nhận việc → hóa đơn → dùng 80.000 point → thiếu số dư bị chặn → khóa → khách báo trả → thợ nhận → đánh giá thành công. Tin tự động nhận việc xuất hiện đúng phòng chat.
- Browser mobile: hẹn trước lưu đúng 24/09/2026 14:00 giờ Hà Nội; yêu cầu sửa hiển thị lý do và chặn xác nhận. Đã sửa lỗi lưu ngày giờ được phát hiện khi kiểm.
- Chi tiết công việc/hóa đơn không tràn ngang ở 360/390/768/1440px; đã xem ảnh mobile 390px và desktop. Đây không phải nghiệm thu mọi màn/breakpoint hoặc app native.
- Chưa kiểm accessibility tự động toàn bộ v0.3, chưa thử với người dùng thật. Build Storybook có cảnh báo chunk và không ghi được global settings; không ảnh hưởng kết quả build.

## Tác động tài liệu

DOC-050 prototype, PLAN-006 nền tảng, DOC-053 phạm vi thiết kế, DOC-052 hướng dẫn thử, DOC-054 README và DOC-056 này được cập nhật; Excel và ZIP cùng Drive ID được đồng bộ. BRD/FR/NFR/SRS, sơ đồ nghiệp vụ, quyền/trạng thái, ERD/API giữ nguyên vì không thay đổi nghiệp vụ. DOC-008 vẫn là bản mô phỏng nghiệp vụ rộng hơn; không gắn trạng thái hoàn thiện sản phẩm cho bản React.

## Bổ sung v0.4

Khách và partner dùng chung việc/hóa đơn/chat/ví. Tin riêng khách–nhân viên tách khỏi cửa hàng; panel mô phỏng cũ được thay bằng chuyển vai trò thử. Kết quả kiểm v0.4 và giới hạn: [DOC-057](partner-journey.md). UI khách v0.3 đã được chủ dự án xem và đồng ý trước đợt này.

UI-08: hồ sơ đã lưu từ partner cập nhật tìm kiếm/hồ sơ khách và danh sách kỹ năng form thuê trong cùng lượt thử. Danh mục và khoảng cách vẫn là mẫu, chưa có tính vùng phục vụ thật.
