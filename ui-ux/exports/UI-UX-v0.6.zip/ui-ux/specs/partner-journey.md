# Partner và doanh nghiệp — React v0.5

DOC-057 · 23/09/2026 · UI-06. Chủ dự án đã xem và đồng ý nhóm UI khách v0.3, cho làm tiếp nhóm partner/doanh nghiệp. Đây là thiết kế thao tác với dữ liệu mẫu, chưa phải sản phẩm hoặc nghiệm thu bảo mật backend.

## Điểm vào

Mở `http://127.0.0.1:5178/`, chọn **Đang xem thử với vai trò** ở đầu trang. Các lựa chọn là tài khoản mẫu khác nhau: khách Anh Tuấn, thợ Minh, quản lý An Tâm, nhân viên Dũng/Hà và các partner mẫu còn lại. Thanh này phục vụ review, không phải chức năng giả danh tài khoản trong sản phẩm.

Storybook có thêm **Partner · thợ tự do**, **Partner · doanh nghiệp**, **Partner · nhân viên**, **Mobile · partner**. Tổng 20 stories. Cổng 6006 hiện phục vụ `storybook-static`; sau chỉnh code cần build lại và tải lại trang. Vite 5178 vẫn là bản dev.

```mermaid
flowchart LR
 A[Khách gửi yêu cầu] --> B[Partner nhận việc]
 B --> C{Loại partner}
 C -->|Tự do| E[Người thực hiện]
 C -->|Doanh nghiệp| D[Quản lý giao trực tiếp]
 D --> E
 D --> P[Chat riêng khách với nhân viên]
 E --> F[Ảnh kết quả]
 F --> G[Nhập vật tư và tiền công]
 G --> H[Khách kiểm hóa đơn / chọn point]
 H --> I[Khóa hóa đơn và giữ phí]
 I --> J[Khách báo trả tiền]
 I --> K[Người thực hiện xác nhận nhận tiền]
 K --> L[Trừ phí / bù point vào ví partner]
 J --> M[Đủ hai xác nhận: mở đánh giá]
 K --> M
```

## Phân quyền trong bản mẫu

| Vai trò | Được thao tác |
|---|---|
| Thợ tự do | Bật/tắt nhận việc, nhận/từ chối yêu cầu, ảnh/nháp/hóa đơn, nhận tiền, chat, ví |
| Quản lý cửa hàng | Nhận việc, giao/đổi người phụ trách, xem hóa đơn, ví và đội ngũ. Có thể giao cho chính mình để thực hiện |
| Nhân viên | Chỉ xem/thực hiện việc được giao, gửi hóa đơn trực tiếp không chờ duyệt, nhận tiền, chat riêng với khách; không có Ví/Đội ngũ |

Khi đổi người, người cũ mất quyền thực hiện công việc nhưng lịch sử chat riêng vẫn giữ. Phòng được nhận dạng theo cặp khách–nhân viên, không theo mã việc. Quản lý chỉ thấy phòng của cửa hàng, không thấy tin riêng của nhân viên. Lịch sử phân công lưu trong công việc. Không phân công lại sau đã xác nhận nhận tiền.

## Các tương tác đã dựng

- Công tắc nhận việc ẩn partner khỏi tìm kiếm và chặn yêu cầu mới; việc cũ không bị xóa. Danh sách việc có lọc và tìm theo mã/dịch vụ/khách.
- Một quản lý và hai thợ mẫu; không tạo tài khoản điều phối bắt buộc. Nhận đơn rồi giao trực tiếp hoặc tự thực hiện.
- Ảnh kết quả trước khi nhập hóa đơn: chọn ảnh cục bộ hoặc nút ảnh minh họa để thử. Ảnh chỉ ở bộ nhớ trình duyệt, không tải lên server. Vật tư/công bắt buộc là số nguyên không âm, cho phép 0; không đặt trần giá trị nghiệp vụ.
- Nháp theo công việc giữ khi chuyển màn/vai trò trong phiên. Hóa đơn gửi lại sau khách yêu cầu sửa tăng phiên bản; khách đã khóa thì không chỉnh nội dung/point. Ảnh và mô tả hiển thị cả phía khách.
- Xác nhận nhận tiền cần kiểm tra nội dung và đánh dấu đã nhận đủ; chỉ người thực hiện hiện tại được làm. Có thể nhận trước hoặc sau khách báo trả; đánh giá vẫn chờ cả hai.
- Ví tách số dư, giữ phí, giữ rút, có thể rút và khả dụng trả phí. Hạn mức âm 100.000đ chỉ trả phí, không rút. Không cộng tiền khách trả trực tiếp vào ví nền tảng.
- Nạp/rút tạo yêu cầu chờ admin. Rút giữ tiền ngay; nạp đang chờ không tăng số dư. Một ngân hàng nhận tiền mẫu đã xác minh; không có chuyển tiền/QR thật. Chưa có nút admin duyệt trong React đợt này.

## Ví dụ đối chiếu đã thử

Công 200.000đ + vật tư 100.000đ; khách dùng 80.000 point, trả trực tiếp 220.000đ. Phí 20.000đ, thưởng khách 2.933 point theo công thức hiện hành. Khi Dũng xác nhận nhận tiền, ví cửa hàng 500.000 → 560.000đ (bù 80.000 − phí 20.000). Sau yêu cầu rút 100.000đ: giữ rút 100.000, có thể rút 460.000, khả dụng phí 560.000đ. Thử rút 600.000đ trước đó bị chặn.

## Kiểm chứng và giới hạn

- 16 kiểm tra logic đạt: 8 luồng khách và 8 bổ sung quyền, ảnh bắt buộc, bàn giao, hai phía, lặp nhận tiền, giữ phí/rút, tách ví theo partner và hạn mức âm không được rút.
- Browser đã chạy quản lý nhận → giao Dũng → Dũng gửi ảnh mẫu/hóa đơn → khách dùng point/khóa/báo trả → Dũng nhận tiền → ví đúng. Tin khách gửi riêng cho Dũng không xuất hiện ở phòng cửa hàng. Tắt An Tâm giảm kết quả tìm kiếm từ 4 xuống 3.
- Build Vite/Storybook đạt. Danh sách partner không tràn ngang ở 360/390/768/1440px; đã xem màn phân công mobile 390px. Giao KV-002 cho cùng Dũng giữ cả tin cũ và tin nhận KV-001 trong một phòng chat. Chưa kiểm WCAG toàn bộ hoặc thiết bị native thật.
- Dữ liệu chỉ trong bộ nhớ phiên, tải lại sẽ mất. Tất cả tài khoản/đơn/bank là mẫu. Quyền chỉ được mô phỏng ở frontend; không thay thế xác thực/phân quyền server.
- Hồ sơ giới thiệu/kỹ năng/vùng phục vụ/giá tham khảo đã có trình sửa trong React; mời/nghỉ nhân viên, phân quyền tùy chỉnh và ngân hàng chỉnh sửa vẫn tra prototype nghiệp vụ 8765. Không tuyên bố đã chuyển toàn bộ các màn phụ sang UI mới.
- Admin React, duyệt nạp/rút thực, report ngoại lệ tài chính, kết nối thanh toán/gọi/nhắc lịch chưa triển khai. Q02 phải giải quyết trước tiền thật. PROMO-02 không đổi.

## Đồng bộ

DOC-050, DOC-052, DOC-053, DOC-054, DOC-056, PLAN-006 và DOC-057 cùng registry/ZIP được cập nhật. BRD/FR/NFR/SRS/quyền-trạng thái/ERD/API và DOC-008 không đổi: đợt này áp dụng nghiệp vụ đã chốt vào UI, không thêm yêu cầu sản phẩm. Bộ thử Figma/Penpot lưu nguyên làm lịch sử.

## Điều hướng mobile — UI-07

Thanh điều hướng cố định dưới màn hình, cùng cách sử dụng với phía khách. Thợ tự do có Công việc, Ví, Hồ sơ, Tin nhắn; quản lý doanh nghiệp thêm Đội ngũ; nhân viên có Công việc và Tin nhắn. Mục đang chọn có nền và màu nổi bật. Nội dung chừa khoảng trống và safe area để không bị thanh dưới che. Desktop giữ thanh ngang phía trên. Thay đổi trình bày, không đổi phân quyền hay nghiệp vụ.

Kiểm tra UI-07: build Vite/Storybook thành công; trình duyệt 360/390/768px thanh dưới fixed, 1440px thanh ngang; không tràn ngang. Quản lý chuyển được sang Ví, nhân viên chỉ có Công việc/Tin nhắn. Chưa kiểm nghiệm bàn phím trên thiết bị native.

## Hồ sơ năng lực — UI-08, v0.5

Sau khi chủ dự án duyệt điều hướng UI-07 và yêu cầu tiếp tục, chuyển nhóm hồ sơ đã có trong UX nghiệp vụ sang React. Vào **Hồ sơ** ở thanh dưới (chủ/quản lý), hoặc Storybook **Mobile · chỉnh sửa hồ sơ**. Bốn nhóm: giới thiệu/kinh nghiệm; kỹ năng; khu vực và địa chỉ cửa hàng; giá công/kiểm tra/di chuyển tùy chọn. Có xem trước và khôi phục bản đã lưu. Tối thiểu một kỹ năng, một khu vực; giá số nguyên không âm, trống là chưa công bố, 0 là giá 0đ.

Lưu cập nhật dữ liệu chung của phiên: khách tìm không dấu theo kỹ năng, xem hồ sơ và chọn kỹ năng trong form thuê. Công việc cũ giữ bản thông tin tại lúc thuê. Nhân viên không có quyền sửa hồ sơ doanh nghiệp. Bản nháp chưa lưu mất khi rời màn; bản đã lưu giữ trong lượt thử, tải lại trang mất.

Danh mục kỹ năng và khu vực là tập mẫu; không phải toàn bộ bộ dữ liệu nhiều ngành. Khu vực lưu/hiển thị nhưng chưa geocode hay tính lại khoảng cách và vùng phục vụ thực. Ảnh năng lực, chứng chỉ, xác minh và danh mục toàn hệ thống chưa chuyển sang nhóm này. Đây là prototype, không có lưu server.

QA: 16 kiểm tra logic cũ đạt; browser chặn không chọn kỹ năng, lưu Sửa máy giặt, khách tìm không dấu ra An Tâm, xem phí kiểm tra 0đ và thuê đúng kỹ năng. Bố cục kiểm 360/390/768/1440px; build Vite/Storybook.
