# Đợt 2 — Công việc, đánh giá và liên lạc · React v0.10

DOC-059 · UI-14 · 23/09/2026. Chủ dự án yêu cầu làm tiếp sau đợt 1. Chuyển các nghiệp vụ đã chốt sang React/Storybook; chưa triển khai backend.

## Điểm vào

- Công việc → chọn việc → Lịch hẹn và thay đổi. Đổi ngày/giờ hoặc rút/dừng với lý do. Hai bên đã trao đổi; không có bước duyệt lại lịch.
- Công việc hoàn tất → Đánh giá sau công việc. Chuyển vai để thử đánh giá chiều còn lại, trả lời và đề nghị xem xét.
- Tin nhắn → chọn người → Gọi trong app. Thông báo mở riêng bằng chuông header; cài đặt tại Tài khoản → Cài đặt → Thông báo (UI-15).
- Storybook: Công việc · đổi lịch và dừng; Đánh giá · hai chiều; Liên lạc · hộp thư khách / hộp thư partner; Thông báo · cài đặt; Mobile · công việc và liên lạc. Tổng hiện hành 39 stories sau UI-15.

```mermaid
flowchart LR
 A[Chi tiết công việc] --> B[Đổi lịch hoặc rút/dừng]
 B --> C[Tin hệ thống và lịch sử]
 B --> D{Có chi phí?}
 D -->|Có| E[Hóa đơn phần đã làm]
 D -->|Không| F[Đã hủy]
 E --> G[Khách báo trả và thợ nhận tiền]
 G --> H[Đánh giá hai chiều]
 H --> I[Trả lời / đề nghị xem xét]
 A --> J[Chat đúng người]
 J --> K[Gọi mô phỏng / lịch sử]
 J --> L[Thông báo / cài đặt]
```

## Quy tắc áp dụng

- Việc đã nhận không tự hết hạn. Đổi lịch tương lai theo giờ Hà Nội; chỉ trước khóa hóa đơn, không áp dụng khi đã dừng. Lưu lịch sử, dùng lịch mới để thử nhắc 24h/1h; thông báo nhắc cũ được ghi đã thay lịch.
- Yêu cầu chờ: khách rút, partner từ chối, cần lý do. Việc đã nhận: khai báo đã trao đổi; không có chi phí thì hủy, có chi phí thì chờ lập/sửa hóa đơn thực tế. Không đổi tiền/point hoặc mở lại tài chính ngoại lệ.
- Chỉ đánh giá khi có cả hai dấu thanh toán trong dữ liệu mẫu. Mỗi chiều một đánh giá; ảnh chỉ ghi tên tệp, trả lời và gửi đề nghị xem xét không tự ẩn đánh giá. Chưa có admin duyệt trong đợt này.
- Chat trước thuê, lịch sử giữ theo cặp tài khoản. Partner có ba khách mẫu để xem bố cục hộp thư nhiều khách; Mai/Hùng là dữ liệu minh họa độc lập, chưa có tài khoản phía khách để đăng nhập. Tin có customerId, không lẫn phòng; phòng nhân viên theo người được giao, quản lý không đọc được phòng đó.
- Gọi cần việc đã nhận và quan hệ liên hệ còn hợp lệ; cửa hàng là Quản lý An Tâm mẫu. Sau hoàn tất vẫn gọi lại; nhân viên đã rời không gọi theo phân công cũ. Người dùng chọn chat thợ hoặc cửa hàng từ chi tiết việc. Chưa có UI thay đầu mối gọi.
- Màn gọi: quyền mic mẫu, gọi ra/đến, nhận/từ chối, không trả lời/bận, mic/loa, mất kết nối/kết thúc; kết quả lưu vào đúng chat. Không ghi âm, không dùng mic thật, không có WebRTC hoặc thời lượng thật. Đổi vai/rời khu vực đang gọi không mô phỏng cuộc gọi chạy nền.
- Tắt riêng thông báo tin nhắn/chuông gọi; thông báo trong app vẫn giữ. Cài đặt theo tài khoản mẫu; công việc và nhắc lịch có tùy chọn riêng. Không email quảng cáo; thông báo an toàn không bị tắt.

## Kiểm chứng và giới hạn

- 33 test logic đạt (29 trước + 4 nhóm mới): đổi lịch, hủy/dừng, điều kiện đánh giá, quyền gọi sau hoàn tất/rời doanh nghiệp. Build Vite và Storybook đạt.
- Browser: lưu ngày/giờ hẹn và lịch sử; mở đúng chat; gửi tin, xem phía partner; gọi mẫu và kết thúc; tắt chuông vẫn ghi lịch sử; đánh giá hai chiều, trả lời; dừng có chi phí giữ việc chờ hóa đơn. Bố cục mobile/desktop được rà soát.
- Nhắc lịch dùng nút mô phỏng, chưa có worker chạy nền; thông báo chưa có push/email/đa thiết bị hoặc bảo đảm giao nhận. Tin gửi lỗi/thử lại là mô phỏng, không phải retry mạng thật.
- Số sao trên hồ sơ tìm kiếm vẫn là fixture, chưa tổng hợp từ đánh giá mới. Xử lý ẩn/gỡ và tính lại sao ở nhóm admin; không tuyên bố đã nối tổng hợp server.
- Dữ liệu trong phiên, tải lại sẽ mất. Các quyền kiểm tại prototype không thay thế phân quyền server. Ảnh đánh giá chỉ tên tệp; không dùng chứng cứ thật.
- Các mục pending giữ nguyên: banner/voucher, OAuth xã hội, EN/JA, chuyển chủ/đóng doanh nghiệp, chặn/báo cáo liên lạc, tranh chấp nâng cao, đảo tiền và khoản giữ treo. Báo cáo hỗ trợ/admin là đợt 4; không có nút tự hoàn tiền trong đợt này.

## Đồng bộ

DOC-050, DOC-056, DOC-057, DOC-058 (đường vào liên lạc), PLAN-006, README, registry v1.20 và ZIP UI-UX-v0.12. BRD/FR/NFR/SRS/API/ERD và wireframe nghiệp vụ không đổi: đây là bản thể hiện UI của quyết định cũ, không chốt dịch vụ bên ngoài hoặc chính sách mới.

## UI-15 — Thông báo và cài đặt tách khỏi tin nhắn (23/09/2026)

Chủ dự án đã duyệt sau tham khảo LinkedIn/Airbnb. React v0.10a: chuông ở header khách/partner/doanh nghiệp mở trang Thông báo riêng, huy hiệu số chưa đọc, Tất cả/Chưa đọc và đánh dấu đã đọc. Bấm thông báo mở đúng việc/phòng chat và cập nhật huy hiệu. Tin nhắn chỉ chứa hộp thư/chat/gọi. Tài khoản → Cài đặt → Thông báo là đường quản lý tùy chọn. Tắt push vẫn giữ thông báo trong app.

Partner/doanh nghiệp dùng thanh dưới Công việc / Ví / Tin nhắn / Tài khoản; nhân viên không có Ví. Hồ sơ cung cấp dịch vụ, Đội ngũ (theo quyền), tài khoản doanh nghiệp của nhân viên nằm trong Tài khoản. Không đổi quyền hoặc nghiệp vụ. Header desktop dùng cùng điểm vào chuông; mobile không thêm tab thứ năm. Bản mẫu vẫn chưa kết nối push thật.

Kiểm chứng: build Vite/Storybook; browser mở chuông/lọc chưa đọc, đường cài đặt, Tin nhắn không còn menu phụ, partner mở thông báo vào đúng chat và giảm huy hiệu. Mobile 390px không tràn ngang. Gói UI-UX-v0.13; registry v1.21.
