# Đợt 1 — Tài khoản, địa chỉ, đăng ký partner · React v0.9

DOC-058 · 23/09/2026 · UI-12. Chủ dự án đồng ý làm gộp đợt 1. Đây là thiết kế tương tác React/Storybook, không phải hệ thống xác thực hay xét duyệt production.

## Xem và thử

Mở Tài khoản ở thanh dưới. Các đường vào: Thông tin và bảo mật; Địa chỉ đã lưu; Trở thành partner. Storybook bổ sung Tài khoản · tổng quan / đăng nhập / bảo mật / khôi phục, Khách · địa chỉ, Partner · đăng ký và xác minh, Mobile · tài khoản và đăng ký. Tổng 31 stories.

```mermaid
flowchart LR
 A[Tài khoản] --> B[Đăng nhập hoặc đăng ký]
 B --> C[Xác minh mẫu]
 C --> D[Tiếp tục chat hoặc thuê đang chờ]
 A --> E[Bảo mật / khôi phục / yêu cầu xóa]
 A --> F[Địa chỉ đã lưu]
 F --> G[Tìm quanh địa chỉ / dùng khi thuê]
 A --> H[Đăng ký partner]
 H --> I[Loại / tên / năng lực / kỹ năng / khu vực]
 I --> J[Xem trước / công bố chưa xác minh]
 J --> K[Gửi giấy tờ / trạng thái / bổ sung]
```

## Phạm vi đã dựng

- Điện thoại/OTP, đăng ký điện thoại mẫu mới; email/mật khẩu, đăng ký và xác minh email; quên/đặt lại mật khẩu. Sai mã/hết hạn/gửi lại; mã mẫu 123456, mật khẩu ban đầu Demo12345. Đăng nhập từ chat tiếp tục đúng phòng. Email cần xác minh điện thoại trước gửi thuê.
- Thông tin cá nhân; đổi điện thoại/email hai bước, giữ kênh cũ trước bước cuối; xung đột mẫu 0900000099/trung@example.com bị chặn. Đổi mật khẩu và kết thúc phiên mẫu khác. Khôi phục gửi chứng cứ mô tả, yêu cầu xóa có xác nhận mất point/xác thực lại và danh sách nghĩa vụ mẫu; cả hai chờ admin, không tự khôi phục hoặc xóa thật.
- Địa chỉ thêm/sửa/xóa/mặc định, chọn tìm quanh địa chỉ, dùng trong form thuê. Sửa/xóa địa chỉ không thay địa chỉ đã chụp vào công việc cũ. Sơ đồ chọn điểm và từ chối vị trí là tình huống mẫu, chưa định vị/geocode.
- Đăng ký thợ tự do/cửa hàng/doanh nghiệp theo 5 bước; giới thiệu, kinh nghiệm, kỹ năng đa ngành, giá tham khảo, ảnh năng lực, khu vực, địa chỉ và riêng tư. Nháp giữ khi chuyển màn trong lượt thử. Hồ sơ công bố hiện trong tìm kiếm với trạng thái xác minh riêng; không cho thuê chính hồ sơ mình.
- Danh tính/chuyên môn và doanh nghiệp khi áp dụng: tên tệp chứng minh, gửi xét duyệt, cần bổ sung/không đạt/đã xác minh. Phần phản hồi admin nằm trong công cụ mô phỏng, không là quyền của partner. Thay đổi xác minh danh tính của hồ sơ đã công bố cập nhật danh sách mẫu.

## Giới hạn cần phân biệt

- Một tài khoản thử trong mỗi Journey, các vai partner khác là tài khoản mẫu để review. Đăng ký tài khoản mới thay dữ liệu tài khoản mẫu và làm mới việc/chat/hồ sơ vừa đăng ký; không phải kho nhiều tài khoản. Dữ liệu mất khi tải lại.
- Không OTP/email/SMS thật, không OAuth, không token/session backend, không kiểm duyệt thật. Link email được mô phỏng bằng bước nhập mã; hạn 5 phút mô phỏng và độ dài mật khẩu 8 chỉ để thử UI, chưa là chính sách sản phẩm được chốt.
- Tệp ảnh/giấy tờ chỉ ghi tên tệp trong bộ nhớ; không đọc/tải lên server. Ảnh public vẫn minh họa. Không dùng dữ liệu nhạy cảm thật.
- Địa điểm có thể đổi nhãn và được lưu vào form; khoảng cách/kết quả địa lý vẫn dữ liệu mẫu, chưa tính lại bán kính thực. Danh mục kỹ năng là 10 ngành/20 kỹ năng hiện có.
- Hồ sơ mới nối tìm kiếm/xem hồ sơ/xác minh; chưa tự tạo tổ chức, đội ngũ và quyền vận hành doanh nghiệp production. Tổ chức An Tâm mẫu tiếp tục dùng để thử công việc/đội ngũ. Không coi đăng ký doanh nghiệp là đã hoàn tất provisioning backend.
- Admin xử lý khôi phục/xóa/xác minh chính thức nằm trong đợt 4. Checklist xóa chỉ dựa việc/yêu cầu ví/hồ sơ mẫu hiện có, chưa phải kiểm toàn bộ nghĩa vụ server. Google/Facebook, chuyển chủ/đóng doanh nghiệp, quảng bá và tài chính ngoại lệ vẫn pending như trước.

## Kiểm chứng

29 test logic đạt: 22 kiểm tra cũ và 7 mới về OTP, đổi kênh hai bước, đăng ký email/điện thoại, đặt lại mật khẩu, yêu cầu khôi phục/xóa, địa chỉ mặc định và snapshot. Browser đã thử OTP sai/đúng; quay lại chat sau login; thêm và đặt mặc định địa chỉ; đăng ký/công bố partner, bổ sung/xác minh và tìm hồ sơ; đổi kênh hai bước. Màn bảo mật không tràn ngang 360/390/768/1440px, xem hình mobile tài khoản. Build Vite/Storybook đạt. Chưa nghiệm thu toàn bộ WCAG, thiết bị native hoặc tích hợp thật.

## Đồng bộ

DOC-050, DOC-052/053/054/056/057, PLAN-006 và DOC-058, registry, ZIP hiện hành đồng bộ. BRD/FR/NFR/SRS/ERD/API/quyền và wireframe nghiệp vụ không đổi: chuyển luồng đã có vào UI mới, không thay nghiệp vụ. Ghi rõ bản mẫu không thay kết quả triển khai sản phẩm.

## UI-13 — Bố cục Point đã duyệt (23/09/2026)

Trong màn Tài khoản, thẻ Point nằm ngay dưới lời chào và trước danh sách quản lý trên cả mobile/desktop. Thẻ ngang nền xanh nhạt, hiển thị số point, giá trị tương đương và “Dùng để thanh toán dịch vụ”. Bỏ cột Point bên phải và đoạn quy tắc dài tại đây. Quy tắc tích/dùng Point giữ nguyên. Bản vá React v0.9a; gói UI-UX-v0.11.zip.

## UI-14 — Đợt 2, React v0.10

[DOC-059](activity-batch.md) bổ sung đổi lịch/rút/dừng, đánh giá hai chiều và liên lạc/thông báo. Các giới hạn cũ về những màn này được thay bằng phạm vi và giới hạn DOC-059. Tài khoản có đường vào Tin nhắn và thông báo; Point vẫn ngay dưới lời chào. Nghiệp vụ tiền không đổi.
