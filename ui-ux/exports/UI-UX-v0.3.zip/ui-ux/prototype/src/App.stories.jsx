import React from'react';import{App,Button,ProviderCard,partners}from'./App';
export default{title:'Dịch vụ quanh bạn/Thử giao diện',component:App};
export const Desktop={render:()=> <App/>};
export const Mobile={render:()=> <App/>,globals:{viewport:{value:'iphone12',isRotated:false}}};
export const NoResults={render:()=> <App initialEmpty/>};
export const VerifiedProfile={render:()=> <div style={{maxWidth:740,padding:24}}><ProviderCard/></div>};
export const UnverifiedProfile={render:()=> <div style={{maxWidth:740,padding:24}}><ProviderCard partner={partners[3]}/></div>};
export const Buttons={render:()=> <div style={{display:'flex',gap:16,padding:32,flexWrap:'wrap'}}><Button>Nhắn tin trước</Button><Button secondary>Xem hồ sơ</Button><Button disabled>Gửi yêu cầu</Button></div>};

export const PartnerProfile={render:()=> <App initialView="profile"/>};
export const ChatBeforeHiring={render:()=> <App initialView="chat"/>};
