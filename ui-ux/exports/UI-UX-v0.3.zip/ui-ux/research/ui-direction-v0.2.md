# Hướng thiết kế UI v0.2 — Dịch vụ khu phố

DOC-053 · 23/09/2026 · Chủ dự án đã chọn hướng A — Dịch vụ khu phố. React + Storybook và hướng thị giác đã duyệt; đã dựng bản mẫu v0.2, chưa triển khai sản phẩm.

## Những gì đã tham khảo

Quan sát trực tiếp website ngày 23/09, không đăng nhập hay tạo giao dịch. Mobile là web ở viewport 390px, không phải kiểm thử ứng dụng native.

| Nguồn | Quan sát | Áp dụng cho dự án |
|---|---|---|
| [Taskrabbit](https://www.taskrabbit.com/) | Tìm nhu cầu trước, nhóm công việc cụ thể, ảnh người đang làm, giá tham khảo và đánh giá. Có popup ưu đãi che nội dung lúc xem. | Gợi ý bằng việc cần làm: sửa vòi nước, vệ sinh điều hòa. Đưa bằng chứng tay nghề gần nút liên hệ. Không đưa popup quảng cáo vào luồng tìm thợ. |
| [Urban Company Delhi](https://www.urbancompany.com/delhi-ncr) | Desktop đặt địa chỉ và tìm kiếm trên đầu, ngành dịch vụ bằng hình, ảnh người làm dịch vụ ở nửa phải. Thu viewport mà không tải lại gây cắt nội dung trong lần quan sát; chưa kết luận chất lượng mobile của hãng. | Dùng hình giúp nhận biết ngành, gắn tìm kiếm với địa chỉ. Không áp dụng thời gian đến hoặc giá cố định vì mô hình dự án chưa có dữ liệu đó. |
| [Airbnb Services](https://www.airbnb.com/services) | Desktop có tìm theo địa điểm/thời gian/loại dịch vụ. Mobile sau tải lại có tìm kiếm gọn, hàng danh mục cuộn ngang, thẻ ảnh công việc, thông tin giá/đánh giá, điều hướng dưới. | Phân cấp ảnh → dịch vụ → thông tin tin cậy. Tách thiết kế mobile và desktop. Không sao chép thương hiệu, ảnh hoặc luồng thanh toán. |

## Ba hướng cân nhắc

| Hướng | Cảm giác và lợi ích | Đánh đổi |
|---|---|---|
| A. Dịch vụ khu phố — đề xuất chọn | Cobalt, ảnh tay nghề, tên thật/cửa hàng, thẻ gọn có bằng chứng. Phù hợp nhiều ngành tại Hà Nội. | Cần ảnh partner đủ chất lượng, có fallback tử tế khi chưa có ảnh. |
| B. Chuyên gia cao cấp | Ảnh lớn, ít nội dung trên màn, hồ sơ trình bày như portfolio. Phù hợp beauty/pet/detailing. | Tốn diện tích và làm chậm việc tìm thợ sửa chữa gấp. |
| C. Tìm thợ tức thời | Bản đồ ưu tiên, danh sách rất gọn, tương tác nhanh. | Dễ gây hiểu nhầm theo dõi GPS/điều phối như gọi xe, ảnh năng lực ít nổi bật. |

## A — Cá tính thị giác

- Màu hành động cobalt `#2457D6`; chữ mực `#16233B`; nền trắng/xám xanh `#F4F7FC`; vàng nhạt `#FFF0B8` chỉ làm điểm nhấn nhỏ. Màu cảnh báo/thành công có icon và chữ đi kèm.
- Be Vietnam Pro, nội dung 16px, nhãn phụ tối thiểu 14px; tiêu đề mobile 28–32px, desktop 36–40px. Chỉ dùng 3 mức độ đậm chính.
- Bo góc 12–16px, nút ít nhất 44px, ảnh có tỷ lệ ổn định, khoảng cách theo thang 4/8/12/16/24/32. Hiệu ứng chỉ phản hồi thao tác, tôn trọng reduced-motion.
- Bộ icon cùng nét, một nét nhận diện đồ họa dựa trên dấu vị trí dùng ở logo/nhãn địa chỉ. Không lặp họa tiết ở mọi thẻ.
- Ảnh công việc do partner cung cấp và có quyền sử dụng. Trong mẫu ghi rõ minh họa; không dùng chân dung giả kèm chứng nhận hoặc review có vẻ thật.
- Khi chưa có ảnh: ảnh đại diện chữ cái + biểu tượng ngành; không tạo vùng ảnh trống lớn. Nội dung mới/ít đánh giá được trình bày trung thực.

## Bố cục đề xuất

```text
MOBILE — TÌM DỊCH VỤ                 DESKTOP — KẾT QUẢ
┌─────────────────────────┐         ┌───────────────────────────────────────────────┐
│ Địa điểm làm việc  ▾     │         │ Logo   Địa điểm   Tìm kiếm   Chat  Tài khoản │
│ Bạn cần giúp việc gì?   │         ├───────────────────────────────────────────────┤
│ [Tìm dịch vụ          ] │         │ Ngành   10 km ▾   Xác minh   Bộ lọc          │
│ Ngành bằng hình + tên   │         ├───────────────────────┬───────────────────────┤
│ 10 km ▾  Bộ lọc  Bản đồ │         │ Kết quả + sắp xếp     │ Bản đồ               │
│─────────────────────────│         │ ┌───────────────────┐ │                       │
│ Ảnh việc + tên partner │         │ │Ảnh │ Năng lực     │ │ Marker chọn đồng bộ  │
│ Kỹ năng · khu phục vụ  │         │ │    │ Giá tham khảo│ │ với thẻ bên trái    │
│ ★ số sao (số đánh giá) │         │ │Nhắn tin · Hồ sơ   │ │                       │
│ Giá tham khảo nếu có   │         │ └───────────────────┘ │                       │
│ [Nhắn tin]  Xem hồ sơ  │         └───────────────────────┴───────────────────────┘
│─────────────────────────│
│ Tìm · Việc · Chat · Tôi│
└─────────────────────────┘
```

- Trang khám phá: ngành dễ nhận biết, tìm kiếm nổi bật, không có hero quảng cáo chiếm toàn màn đầu. Màn kết quả tập trung so sánh, không lặp phần giới thiệu.
- Mobile: danh sách toàn chiều ngang; mở bản đồ ở chế độ riêng, thẻ kết quả ở bảng kéo dưới, vẫn có nút mở danh sách cho người không dùng thao tác kéo. Bộ lọc có Áp dụng/Xóa, hiển thị số điều kiện đang dùng.
- Web: kết quả và bản đồ cùng nhìn được; bỏ sidebar lớn của bản thử. Tablet khi không đủ chỗ chuyển sang nút Danh sách/Bản đồ.
- Hồ sơ: ảnh công việc, phần giới thiệu ngắn, kỹ năng, khu phục vụ, giá tham khảo, review. Nhắn tin là hành động nổi bật; Thuê dịch vụ vẫn dễ tìm và không bắt buộc chat trước.
- Chat trước thuê và lịch sử theo cặp người dùng giữ nguyên. Yêu cầu thuê là thẻ trong cuộc trò chuyện; khi nhận việc có tin hệ thống theo nghiệp vụ đã duyệt.
- Khu partner dùng hàng công việc có hành động rõ; bật/tắt nhận việc đặt ở đầu màn. Admin có giao diện vận hành riêng, không trộn menu quản trị vào tìm thợ.

## UX phải kiểm chứng khi làm mẫu

| Tình huống | Hành vi mục tiêu |
|---|---|
| Khách sửa địa chỉ | Địa chỉ đang tìm luôn thấy được; cập nhật kết quả và vùng bản đồ cùng nhau |
| Khoảng cách | Phân biệt địa chỉ cửa hàng và khu vực nhận phục vụ; không gắn khoảng cách giả cho thợ di động |
| Không có kết quả | Giữ tiêu chí, cho mở từ 10 lên 20/30 km hoặc bỏ bộ lọc; không tự đổi âm thầm |
| Partner chưa xác minh | Nhãn có giải thích; không dùng cùng huy hiệu với đã xác minh |
| Chưa khai báo giá | Ghi Trao đổi để nhận báo giá; không dùng 0đ hoặc giá từ ảo |
| Quay lại từ hồ sơ/chat | Giữ bộ lọc, vị trí cuộn và partner đã chọn |
| Chưa đăng nhập | Xem phần hồ sơ công khai; nhấn liên hệ yêu cầu đăng nhập và quay về hành động đang làm |
| Màn hình nhỏ/bàn phím | Nút chat không che ô nhập; hỗ trợ safe area, focus và bàn phím; không tràn ngang toàn trang |

Tiêu chí mẫu: người xem nhận ra cách đổi địa chỉ, lọc ngành, xem năng lực và mở chat; thử 360/390/768/1440px; kiểm tương phản, focus, trạng thái rỗng/lỗi/đang tải. Đây là mục tiêu kiểm thử, chưa có kết quả đo UX người thật.

## Phạm vi và quyết định cần chốt

Đã chọn A, dựng nhóm 4 màn cùng lúc: tìm dịch vụ mobile, kết quả desktop, hồ sơ partner và chat trước thuê; kèm components trong Storybook. Các hướng B/C chỉ giữ để tra quá trình cân nhắc. Không thêm chức năng yêu thích, gói bảo đảm, thanh toán online hay cam kết thời gian đến.

Nguồn nghiệp vụ vẫn là hồ sơ hiện hành. Thay đổi này là trình bày của bản thử UI DOC-050, không thay thế prototype nghiệp vụ DOC-008 hoặc sửa BRD/SRS/API. Sổ quản lý ghi UI-04 đã chốt hướng; duyệt hướng không đồng nghĩa nghiệm thu mọi trạng thái hoặc triển khai production.

## Bản mẫu đã dựng và khoảng cách với mục tiêu

- Dựng cobalt, typography, bộ minh họa điện nước/điện lạnh/vệ sinh/chăm xe; trang mobile có điều hướng dưới, web có danh sách cạnh sơ đồ; hồ sơ và chat dùng cùng ngôn ngữ thiết kế.
- Minh họa SVG tự tạo, có nhãn; chưa có ảnh công việc partner thật. Bản đồ là sơ đồ giả, không phải dữ liệu địa lý hay vị trí thợ trực tiếp.
- Chưa triển khai chọn địa chỉ, bản đồ có bảng kéo dưới, đăng nhập thật, form thuê, dữ liệu vùng phục vụ thật hoặc xếp hạng kết hợp. Mobile hiện bấm Bản đồ để thêm sơ đồ phía trên danh sách; chưa có thao tác kéo thả. Những mục UX mục tiêu phía trên là công việc tiếp theo, không phải cam kết đã có trong mẫu.
- Lịch sử chat lưu theo partner trong bộ nhớ phiên; refresh sẽ mất, chưa có backend. Không gửi tin nhắn thật.
- Kiểm 23/09: build Vite và Storybook đạt; 8 stories; lọc điện nước + đã xác minh = 1; gửi tin rồi đóng/mở lại cùng partner giữ nội dung; từ màn rỗng xóa lọc/mở 20 km = 5; xem trực tiếp hồ sơ desktop và Storybook mobile 390px.
- Chưa chạy đầy đủ accessibility và mọi breakpoint cho v0.2; kết quả axe v0.1 không dùng làm chứng nhận v0.2. Chưa đo UX với người dùng thật.
