# UI/UX — Dịch vụ quanh bạn

Điểm vào phần thiết kế của dự án. Xem [README dự án](../README.md) để biết cấu trúc toàn hệ thống.

- `prototype/`: React + Storybook hiện hành. Chạy `npm run dev` hoặc `npm run storybook` tại đây.
- `research/`: nghiên cứu, hướng thiết kế và đề xuất; trạng thái phê duyệt ghi trong từng tài liệu.
- `specs/`: phạm vi UX hiện hành.
- `wireframes/`: prototype nghiệp vụ và các viewer HTML; phục vụ localhost:8765.
- `archive/`: bằng chứng và bản thử lịch sử, không tự dùng làm yêu cầu hiện hành.
- `exports/`: ZIP theo phiên bản; bản v0.1/v0.2 là lịch sử, gói v0.3 bổ sung tổ chức thư mục và nghiên cứu quảng bá.

Sổ quản lý toàn dự án: `../docs/project-control/So-quan-ly-tai-lieu.xlsx`. Mã prototype nằm riêng, không đặt chung với `apps/web` để tránh nhầm dữ liệu giả với ứng dụng thật.
