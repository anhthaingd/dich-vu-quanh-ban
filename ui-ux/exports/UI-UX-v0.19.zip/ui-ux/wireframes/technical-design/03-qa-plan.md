# Kế hoạch QA, RTM và UAT

> **P0-1 · 06/10/2026 · v0.1.6 · Đã duyệt: hồ sơ quản lý riêng có version; draft/published, công bố không tự bật nhận việc; phone_verified trước tạo partner, owner và ví rỗng cùng transaction. Tìm theo distance mặc định, vùng tròn đo tới tâm và phải bao phủ khách; cursor theo distance_m/created_at/id, gắn bộ lọc. Tài khoản/provider test tách biệt được phép tạo trực tiếp; OTP, polygon, bản đồ và xếp hạng recommended/rating chưa triển khai. Không production/tiền thật.**

> **B01-04A · 06/10/2026 · v0.1.5: chủ dự án duyệt gộp quản lý phiên và sổ địa chỉ. Một mục phiên đại diện một lần đăng nhập (id = family_id ổn định qua refresh), có created_at, last_seen_at, is_current; state active/expired/revoked; không trả IP, token/hash. Thu hồi chặn toàn bộ family và kiểm lại quyền trong transaction. Địa chỉ thêm is_default/version; địa chỉ đầu tiên khi sổ đang rỗng tự mặc định. Chọn mặc định mới bỏ mặc định cũ và tăng version bản cũ. Gỡ mặc định để chưa có mặc định, không tự chọn mục khác. PUT yêu cầu expected_version. Mọi mutation giữ Idempotency-Key khi retry, kiểm chủ sở hữu; archive giữ dữ liệu lịch sử, không đổi snapshot công việc. Nhập địa chỉ/tọa độ thủ công, chưa chọn GPS/map provider. OTP Pending; không production/chi phí.**

> **B01-04 · 06/10/2026 · v0.1.4:** Bổ sung QA-070/071 cho `Me.version` và sửa tên: schema Session/Me, phiên bị thu hồi khi chờ khóa, chống ghi đè, retry sau mất phản hồi, rollback, bảo toàn bản nháp VI/EN/JA, lưu tên qua mở lại native. Các ca dưới đây là tiêu chí kiểm; kết quả thực tế và giới hạn ghi trong báo cáo B01-04 ở repo.

> **I18N-04 · 05/10/2026 · v0.1.3 (phạm vi danh mục đã duyệt):** Bổ sung QA-067…069 và RTM cho danh mục đa ngôn ngữ: đầy đủ cây/seed bảo toàn dữ liệu, locale/fallback/cursor, đổi ngôn ngữ khi request chậm, chữ dài và retry native. Bằng chứng mới nằm trong báo cáo I18N-04 thuộc bộ kế hoạch repo; các ca lịch sử vẫn giữ ngày cũ.


Phiên bản 0.1.2 · 28/09/2026 · Đợt 1 triển khai local danh mục Expo/NestJS/PostgreSQL/PostGIS. Chi tiết và bằng chứng tại DOC-065; phần ngoài danh mục vẫn là thiết kế, chưa production/tiền thật.

## Phân biệt thiết kế và kết quả chạy

Các ca QA-001…055 toàn sản phẩm vẫn Chưa chạy. Đợt 1 thêm QA-056…059 đã kiểm local; QA-060 native chưa chạy. Không đổi QA-007 (createSkill/admin) hoặc QA-055 rộng hơn thành đạt từ lát đọc danh mục. Kiểm parser DDL/OpenAPI và xem tài liệu không chứng minh backend an toàn, không thay kiểm thử tích hợp PostgreSQL/PostGIS hoặc UAT trên iOS/Android/web.

## Tầng kiểm thử

| Tầng | Thực hiện | Khi chạy |
|---|---|---|
| Unit | Công thức số nguyên, state guard, policy/DTO, tính reminder | Mỗi thay đổi logic |
| Contract | Mỗi operation: input/output schema, field riêng tư, lỗi, auth, version/key | Mỗi PR thay contract |
| Integration | PostgreSQL/PostGIS thật với migration mới; transaction song song, FK/unique/trigger | CI backend; không thay bằng SQLite/mock |
| E2E | App iOS/Android và web theo vai; retry/deep link/offline | Khi hoàn tất lát chức năng |
| Security | Tenant/IDOR, session revoke, signed asset ACL, không lộ thông tin | Mỗi thay đổi quyền và trước ra mắt |
| Recovery | Kill sau commit, worker chết, payout unknown, backup/restore | Trước triển khai module tiền và trước ra mắt |
| Load | Search/map/chat/confirm/queue với dữ liệu thực tế dự kiến | Đặt mục tiêu khi có quy mô; chưa tự nhận 10.000 concurrent |

## Fixtures bắt buộc

Hai doanh nghiệp A/B; một quản lý kiêm nhiều quyền; hai thợ; một người là member cả A/B; một thợ tự do; hai khách; một admin giới hạn và một admin tài chính. Có partner unverified/verified/rejected/off, vùng sát biên, hai việc cùng ví/point, invoice0/toàn point, hai phiên bản, thợ đã rời, review hidden+self-removed và payout unknown. Dữ liệu giả; không dùng thông tin ngân hàng thật trong test.

## Cách chạy ca cạnh tranh

Dùng hai kết nối DB độc lập, barrier đồng bộ trước điểm khóa, không chỉ Promise.all với một transaction. Assert kết quả DB sau cả hai commit/rollback: số settlements, entries, holds theo invoice, balance projection và outbox. Crash inject trước và sau commit. Không chỉ kiểm HTTP200 hoặc đếm callback.

## Điều kiện hoàn thành

- Mọi yêu cầu đang triển khai có FR → operation/schema → ca test → bằng chứng build/commit.
- P0 tiền/quyền chạy pass trên DB thật; không còn lỗi mở gây sai tiền, mất dữ liệu hoặc rò quyền.
- Kiểm transaction cân bằng từng unit, không chỉ số dư cuối; payout unknown không bị release từ timeout.
- iOS/Android/web có hành trình chính và lỗi thực tế; reviewer người dùng duyệt UAT.
- Test pending phải ghi lý do, phạm vi bị chặn và người quyết định; không đổi thành PASS vì mock không hỗ trợ.
- Q02/PLAN-005 chưa giải quyết thì khóa giao dịch tiền thật, kể cả các ca normal-path đã pass.

## Bộ ca nghiệp vụ

Chi tiết ở qa-cases.csv/json. Có 55 ca nghiệp vụ ưu tiên và một CT-<operationId> cho mỗi API. RTM liên kết operation với các ca chuyên sâu; operation chưa có scenario riêng vẫn phải có contract test, không coi là đủ E2E.

| Mã | Nhóm | FR / quyết định | API | Mức | Trạng thái |
|---|---|---|---|---|---|
| QA-001 | Tài khoản | FR-AUTH-001 | verifyOtp | P0 Integration | Chưa chạy |
| QA-002 | Tài khoản | FR-AUTH-001 | login | P0 Integration | Chưa chạy |
| QA-003 | Tài khoản | FR-AUTH-008 | refreshSession | P0 Integration | Chưa chạy |
| QA-004 | Tài khoản | FR-AUTH-005; FR-AUTH-006 | confirmIdentityChange | P0 Integration | Chưa chạy |
| QA-005 | Tài khoản | FR-AUTH-007; FR-ADM-024 | decideRecovery | P0 Integration | Chưa chạy |
| QA-006 | Tài khoản | FR-AUTH-003; FR-ADM-025 | requestDeletion | P0 Integration | Chưa chạy |
| QA-007 | Nguồn cung | FR-CAT-001; FR-CAT-002 | createSkill | P0 Integration | Chưa chạy |
| QA-008 | Nguồn cung | FR-PAR-001 | createPartner | P0 Integration | Chưa chạy |
| QA-009 | Nguồn cung | FR-PAR-003 | setAvailability | P0 Integration | Chưa chạy |
| QA-010 | Nguồn cung | FR-PAR-005; FR-SEARCH-002 | searchPartners | P0 Integration | Chưa chạy |
| QA-011 | Nguồn cung | FR-SEARCH-003; FR-SEARCH-005 | searchPartners | P0 Integration | Chưa chạy |
| QA-012 | Nguồn cung | FR-SEARCH-004 | getPartner | P0 Integration | Chưa chạy |
| QA-013 | Doanh nghiệp | FR-ORG-004; FR-ORG-005 | inviteMember | P0 Integration | Chưa chạy |
| QA-014 | Doanh nghiệp | FR-ORG-001; FR-CHAT-004 | assignJob | P0 Integration | Chưa chạy |
| QA-015 | Doanh nghiệp | FR-ORG-003; FR-ORG-006 | assignJob | P0 Integration | Chưa chạy |
| QA-016 | Doanh nghiệp | FR-ORG-002 | sendInvoice | P0 Integration | Chưa chạy |
| QA-017 | Công việc | FR-JOB-001 | createJob | P0 Integration | Chưa chạy |
| QA-018 | Công việc | FR-JOB-002 | acceptJob | P0 Integration | Chưa chạy |
| QA-019 | Công việc | FR-JOB-003; FR-JOB-004 | rescheduleJob | P0 Integration | Chưa chạy |
| QA-020 | Công việc | FR-JOB-005 | stopJob | P0 Integration | Chưa chạy |
| QA-021 | Liên lạc | FR-CHAT-001; FR-CHAT-006 | openConversation | P0 Integration | Chưa chạy |
| QA-022 | Liên lạc | FR-CHAT-004 | listMessages | P0 Integration | Chưa chạy |
| QA-023 | Liên lạc | FR-CHAT-005 | sendMessage | P0 Integration | Chưa chạy |
| QA-024 | Liên lạc | FR-CALL-001 | startCall | P0 Integration | Chưa chạy |
| QA-025 | Liên lạc | FR-NOT-002; FR-NOT-003 | setSettings | P0 Integration | Chưa chạy |
| QA-026 | Tài chính | FR-INV-001 | sendInvoice | P0 Integration | Chưa chạy |
| QA-027 | Tài chính | FR-INV-002 | saveInvoiceDraft | P0 Integration | Chưa chạy |
| QA-028 | Tài chính | FR-INV-003; FR-INV-004 | confirmInvoice | P0 Integration | Chưa chạy |
| QA-029 | Tài chính | FR-FEE-001; FR-POINT-003 | settleInvoice | P0 Integration | Chưa chạy |
| QA-030 | Tài chính | FR-POINT-001; FR-WAL-003 | confirmInvoice | P0 Integration | Chưa chạy |
| QA-031 | Tài chính | FR-WAL-002 | confirmInvoice | P0 Integration | Chưa chạy |
| QA-032 | Tài chính | FR-POINT-001 | confirmInvoice | P0 Integration | Chưa chạy |
| QA-033 | Tài chính | FR-WAL-002; FR-WAL-005 | createPayout | P0 Integration | Chưa chạy |
| QA-034 | Tài chính | FR-INV-006; FR-ADM-012 | completeOnBehalf | P0 Integration | Chưa chạy |
| QA-035 | Tài chính | FR-INV-006 | settleInvoice | P0 Integration | Chưa chạy |
| QA-036 | Tài chính | FR-INV-007; Q01 | reportPayment | P0 Integration | Chưa chạy |
| QA-037 | Tài chính | FR-INV-008; Q01 | settleInvoice | P0 Integration | Chưa chạy |
| QA-038 | Tài chính | FR-INV-005; Q02 | adminInvoices | P0 Integration | Chưa chạy |
| QA-039 | Tài chính | FR-ADM-012 | completeOnBehalf | P0 Integration | Chưa chạy |
| QA-040 | Tài chính | FR-WAL-004 | adminDecideTopups | P0 Integration | Chưa chạy |
| QA-041 | Tài chính | FR-WAL-005 | adminDecidePayouts | P0 Integration | Chưa chạy |
| QA-042 | Tài chính | FR-WAL-005 | createPayout | P0 Integration | Chưa chạy |
| QA-043 | Tài chính | FR-WAL-001 | getLedger | P0 Integration | Chưa chạy |
| QA-044 | Đánh giá | FR-REV-001; FR-REV-004; Q01 | createReview | P0 Integration | Chưa chạy |
| QA-045 | Đánh giá | FR-REV-005; FR-REV-006 | toggleOwnReview | P0 Integration | Chưa chạy |
| QA-046 | Đánh giá | FR-REV-007 | getJobReviews | P0 Integration | Chưa chạy |
| QA-047 | Admin | FR-SUP-001; FR-ADM-012 | decideReport | P0 Integration | Chưa chạy |
| QA-048 | Admin | FR-ADM-024 | decideUser | P0 Integration | Chưa chạy |
| QA-049 | Admin | FR-CAT-002 | editSkill | P0 Integration | Chưa chạy |
| QA-050 | Hạ tầng | FR-NOT-001 | listNotifications | P0 Integration | Chưa chạy |
| QA-051 | Hạ tầng | FR-INV-006 | getOperation | P0 Integration | Chưa chạy |
| QA-052 | Hạ tầng | FR-INV-001 | completeUpload | P0 Integration | Chưa chạy |
| QA-053 | Hạ tầng | FR-SEARCH-001 | searchPartners | P1 E2E | Chưa chạy |
| QA-054 | Hạ tầng | FR-UX-001 | getMe | P1 E2E | Chưa chạy |
| QA-055 | Hạ tầng | Q03 | getJob | P0 Integration | Chưa chạy |

## UAT theo hành trình

1. Khách chưa đăng nhập tìm vị trí10km → xem profile → đăng nhập → nhắn trước thuê.
2. Khách thuê doanh nghiệp → quản lý nhận/giao → phòng riêng dùng lại → đổi lịch/nhắc đúng.
3. Thợ chụp ảnh/gửi invoice → khách yêu cầu sửa → confirm phiên bản mới → trả trực tiếp → hai dấu → review.
4. Toàn point/0đ → không trả thêm tiền → xác nhận cả hai → review đúng điều kiện.
5. Partner thiếu phí → khách chỉ thấy chờ bổ sung → partner nạp được đối soát → retry confirm không trùng.
6. Hai việc cùng ví; đổi nhân viên; tab cũ mất quyền nhưng chat riêng lịch sử không mất.
7. Payout unknown → admin đối soát → thành công hoặc thất bại đã xác minh, không chuyển lại mù.
8. Khách report → admin xem chứng cứ/preview → hoàn tất thay → sổ đúng, không giả dấu thợ và không tự mở review.

Mẫu ghi kết quả: case_id, môi trường, build/commit, dữ liệu fixture, bước thực hiện, expected, actual, evidence, người chạy, thời gian, PASS/FAIL/BLOCKED. Chưa điền kết quả khi chưa có sản phẩm.

## Kết quả Đợt 1

[DOC-065](../implementation/dot-1.md) ghi lệnh/kết quả và ảnh smoke.

| Mã | Tầng | Kết quả |
|---|---|---|
| QA-056 | Integration | Đạt local 28/09/2026 |
| QA-057 | Integration | Đạt local 28/09/2026 |
| QA-058 | Unit/UI | Đạt local 28/09/2026 |
| QA-059 | E2E web | Đạt local 28/09/2026; không thay native |
| QA-060 | E2E native | Bị chặn: chưa có simctl/adb/thiết bị |


## LOGTEST-01 · 28/09/2026

Phương án A đã triển khai và kiểm local; chi tiết vận hành/bằng chứng tại [DOC-071](../implementation/logging-testing.md). Native còn BLOCKED; `.github/workflows/quality.yml` đã chuẩn bị, chưa push/chạy remote CI.

| Ca | Phạm vi | Kết quả |
|---|---|---|
| QA-061 | Log và correlation | Đạt local 28/09/2026 — DOC-071 |
| QA-062 | Diagnostic mobile | Đạt local 28/09/2026 — DOC-071 |
| QA-063 | DB isolation | Đạt local 28/09/2026 — DOC-071 |
| QA-064 | Log output | Đạt local 28/09/2026 — DOC-071 |
| QA-065 | Quality gates | Đạt local 28/09/2026 — DOC-071 |
| QA-066 | Local concurrency | Đạt local 28/09/2026 — DOC-071 |

API dùng Node test/c8; mobile Jest/RNTL; core ≥90% lines/85% branches, phần còn lại ≥80/70, không bỏ source chưa import. JUnit/HTML/JSON/LCOV và Playwright artifact ở coverage/test-results. Các ca QA001–055 ngoài lát này giữ trạng thái cũ.

## Tiêu chí bổ sung B01-04

- **QA-070** — Kiểm schema Me.version; hai sửa cùng phiên bản; replay cùng key; đổi payload; thu hồi phiên sau bước kiểm đầu; chèn lỗi trước commit. Kỳ vọng: Version tăng đúng một lần; 409 khi xung đột; key tách theo actor; không giả quyền/verified; rollback tên và key cùng nhau; không log tên/token.
- **QA-071** — Sửa tên; đổi tiếng; gây version conflict; tải lại giữ draft; retry cùng key/payload; mở lại native. Kỳ vọng: Không báo lưu giả; giữ draft và key khi chưa rõ kết quả; tên cập nhật header/tài khoản; phiên thu hồi ẩn form; tên đã lưu còn sau mở lại.

## B01-04A — phiên và địa chỉ

- **QA-072** — List/phân trang, thu hồi phiên khác/hiện tại, race refresh/revoke, retry và truy cập chéo. Kỳ vọng: Một mục mỗi family, đúng phiên hiện tại, không lộ token/IP; thu hồi chặn mọi token cùng family, actor khác 404; mất phiên ẩn dữ liệu riêng.
- **QA-073** — CRUD/mặc định, pagination, conflict, mất phản hồi, rollback, đổi ngôn ngữ, khởi động lại. Kỳ vọng: Tối đa một mặc định; gỡ mặc định không chọn thay; không trùng khi retry; 409 sửa cũ; rollback tên/default/key; không lộ địa chỉ; draft giữ khi đổi tiếng.

## P0-1 — nguồn cung và tìm dịch vụ

- **QA-074** — Tạo draft, điền kỹ năng/vùng/cửa hàng, công bố và nhận việc; sửa cạnh tranh, mất response, mất quyền, rollback. Ví rỗng cùng transaction; nháp riêng tư; đầy đủ theo mọi mode; shared version; replay kiểm lại quyền; tắt/nháp loại khỏi search; không cấp verified từ client.
- **QA-075** — Lọc kỹ năng/mode/category/verified; biên vùng/bán kính; cursor đổi filter; đổi vị trí liên tục; xem profile VI/EN/JA/anonymous. Lọc trước xếp hạng; mỗi partner một kết quả; vùng phủ khách và tâm trong radius; distance cursor không lặp trên tập ổn định; không rò địa chỉ riêng; phản hồi cũ không ghi đè mới.

## MAP-01 — chọn địa điểm, thử local ngày 07/10/2026

Theo yêu cầu triển khai tiếp sau khi chốt MapLibre + Geoapify Free: bộ chọn chung cho tìm dịch vụ, sổ địa chỉ, cửa hàng và tâm vùng. Có nhập địa chỉ/gợi ý, tìm cả chuỗi, chạm/kéo bản đồ, GPS khi bấm nút và địa chỉ đã lưu. Theo yêu cầu MAP-03 ngày 07/10/2026, bỏ nút và ô nhập tọa độ thủ công ở cả bốn nơi; tọa độ vẫn được lấy từ địa điểm đã chọn để tìm/lưu theo API hiện có. Người dùng chọn kết quả và xác nhận; không tự lấy dòng đầu. Gõ truy vấn khác hủy lựa chọn cũ, sửa mô tả tầng/phòng giữ ghim. Hủy không sửa form. Đổi tài khoản xóa bản nháp riêng; phản hồi cũ không ghi đè điểm mới.

Ba POST `/v1/locations/autocomplete`, `/geocode`, `/reverse` nhận JSON body theo OpenAPI v0.1.7. Query 3–300 ký tự, locale vi/en/ja, tối đa 5 gợi ý. Tra ngược giữ chính điểm yêu cầu, rỗng/lỗi vẫn cho nhập mô tả sau khi có điểm. Khách chưa đăng nhập được tra cứu với hạn mức IP; bearer hợp lệ dùng tài khoản. Pilot một tiến trình: 4 lookup/giây, 30/actor/phút, 1000/24h; restart reset bộ đếm. 429 có Retry-After; timeout provider 6 giây trả 504 TIMEOUT. Các giới hạn này không bao gồm tile và không phải bảo đảm chặn chi phí toàn project.

Key tra cứu ở server; key tile công khai ở app. Chưa billing/production, chưa dùng Google. Không ghi log địa chỉ/tọa độ/key, không lưu lịch sử GPS. Geoapify và OpenStreetMap được ghi nguồn. Bản đồ nền do app tải trực tiếp; không gửi token dự án tới Geoapify.

Không migration: giữ `{text, point}` và quyền/version/idempotency của API lưu hiện hành. `source` chỉ ở state app, ID gợi ý chỉ tạm. Tâm vùng không thành vị trí thợ công khai; chỉ điểm cửa hàng đã công khai được vẽ trong hồ sơ. Polygon, gom ghim toàn bộ kết quả, routing/ETA và theo dõi thợ ngoài đợt. Bằng chứng code/local/native ở báo cáo B03-01 trong repo; không suy ra UAT/production.

## MAP-02 — bản đồ kết quả, API v0.1.8

MAP-02 — 07/10/2026, quyết định đã chốt: chỉ ghim địa điểm đã đánh dấu công khai; người chưa có điểm công khai vẫn hiện trong danh sách. Mở rộng bản đồ kết quả sau MAP-01, trước P0-2; thay phần loại trừ bản đồ kết quả của MAP-01. Giữ MapLibre + Geoapify Free, chưa billing/production.

Sau khi tìm, khách chuyển Danh sách/Bản đồ trên cùng kết quả và bộ lọc. Điểm cần dịch vụ màu xanh lá, địa điểm công khai màu xanh dương; bấm ghim xem tên, địa chỉ và mở hồ sơ. Ghim trùng tọa độ gom chung nhưng vẫn chọn được từng người. Người không có ghim nằm trong danh sách bên dưới; có thể chuyển về danh sách đầy đủ. Chỉ vẽ các kết quả đã tải; Xem thêm bổ sung cả danh sách và ghim. Đổi điểm hoặc gửi tìm mới bỏ kết quả cũ. Lỗi nền bản đồ cho thử lại hoặc chuyển danh sách.

OpenAPI v0.1.8: GET /v1/partners thêm PartnerCard.map_location bắt buộc, giá trị Address {text, point} hoặc null. Với mỗi người đủ điều kiện tìm kiếm, lấy địa điểm active=true, public=true gần điểm tìm nhất và nằm trong bán kính; hòa khoảng cách chọn created_at rồi id. Không có điểm phù hợp trả null, không loại người khỏi kết quả. Giữ nguyên điều kiện công bố/nhận việc/kiểm duyệt, thứ tự, bộ lọc và cursor. distance_m/distance_kind tiếp tục phục vụ xếp hạng theo cửa hàng hoặc tâm vùng, không suy ra khoảng cách tới ghim.

Không dùng hoặc trả service_areas.center làm ghim; không lộ địa điểm private/đã lưu trữ. Đây là địa điểm khai báo công khai, không phải GPS trực tiếp của thợ. Không migration, không đổi quyền ghi public/private. Không thêm tra cứu provider theo từng thợ, routing, ETA hoặc tracking. Bằng chứng và ảnh chạy app ở báo cáo B03-02 trong repo; kiểm local/simulator không thay UAT hoặc phê duyệt production.

## MAP-03 / P0-2 — phạm vi đã duyệt ngày 07/10/2026

MAP-03 và P0-2 — quyết định chủ dự án ngày 07/10/2026, API v0.1.9.
Bỏ nút và ô nhập tọa độ thủ công trong tìm kiếm, sổ địa chỉ, cửa hàng, vùng phục vụ và form thuê. Người dùng chọn địa chỉ/gợi ý, ghim bản đồ, GPS theo nút hoặc địa chỉ đã lưu; tọa độ vẫn là dữ liệu nội bộ/API. Phần mô tả nhập tọa độ trong các mốc trước là lịch sử đã được thay thế.
Job bổ sung service_mode, time_mode, location_id (null ngoài cửa hàng), note và eta (null trước nhận/hẹn trước). Làm ngay bắt buộc ETA khi nhận; lưu thời điểm dự kiến đến và lịch ban đầu, không thêm nút Bắt đầu. Đổi lịch cập nhật scheduled_at, giữ eta ban đầu và tăng schedule_version/lịch sử. PartnerProfile bổ sung public_locations gồm id + address chỉ cho địa điểm active/public, và service_modes theo skill_id; không trả tâm vùng hoặc điểm riêng. Máy chủ đối chiếu location_id với cửa hàng hiện hành và lấy địa chỉ từ DB, không tin địa chỉ cửa hàng do client gửi.
Gói P0-2 local/test: khách tạo/đọc/rút yêu cầu, partner nhận/từ chối, đổi lịch/dừng trước hóa đơn khóa, phân công theo quyền. Có chi phí đã thỏa thuận thì dừng vẫn giữ accepted để tiếp tục hóa đơn ở P0-3; lưu cờ và lý do, không tạo hóa đơn giả. Không có chi phí chuyển stopped. Không tự hết hạn, hủy hay hoàn tất theo giờ. Giữ xác minh điện thoại ở backend khi gửi/nhận; chỉ dùng tài khoản DEMO local/test đã được duyệt, OTP thật Pending.
Chat tối thiểu dùng API HTTP: tạo/mở lại phòng trước thuê, gửi/đọc tin văn bản, thứ tự sequence, chống trùng client_message_id và idempotency, mốc đã đọc chỉ tăng, tải lại khi quay lại màn/app hoặc bấm cập nhật. Khách–cửa hàng/doanh nghiệp tách khách–nhân viên; phân công thêm tin hệ thống trong phòng riêng. Đổi người không sao chép lịch sử; người cũ giữ chat của mình nhưng mất quyền việc sau thu hồi/phân công lại. Ghi sự kiện bền vững cùng transaction; WebSocket/worker phát sự kiện, push/nhắc lịch, gọi và file đính kèm chưa nghiệm thu trong gói HTTP này. Các yêu cầu sản phẩm đầy đủ vẫn giữ, không coi phần chưa triển khai đã hoàn tất.
Bằng chứng code/local, web và native nằm trong báo cáo B03-03/B03-04 ở repo; không thay CI từ xa, UAT, production hoặc tiền thật.

## P0-3 / local-test — 07/10/2026

P0-3 — chủ dự án đồng ý cả hai bổ sung cho local/test ngày 07/10/2026.
Invoice trả thêm note (chuỗi ghi chú của phiên bản đang xem) và revision_reason (lý do yêu cầu sửa gần nhất, null nếu chưa có). Hai trường này đưa nội dung đã có trong nghiệp vụ/Storybook tới app, không đổi quy tắc tiền, quyền hoặc trạng thái. Khách không thấy bản nháp chưa gửi; trong khi người thực hiện sửa, khách tiếp tục thấy bản đã gửi gần nhất và lý do sửa. Bản gửi và bản khóa bất biến.
Kho ảnh local chỉ dùng DEMO/test, bật bằng LOCAL_ASSET_DIRECTORY và LOCAL_ASSET_ORIGIN; từ chối bật trong NODE_ENV=production. Giữ contract cấp quyền tải lên → tải bytes theo URL → complete → ready. URL ký ngắn hạn và kiểm lại phiên/quyền công việc lúc đọc; không mở thư mục tĩnh công khai. Cấu hình adapter thử: JPEG/PNG/WebP, 10 MiB, 25 triệu pixel, tối đa 100 grant/tài khoản/giờ, URL 10 phút. Complete giải mã ảnh, loại metadata và lưu PNG. Đây là giới hạn kỹ thuật adapter thử, không phải quyết định provider hoặc giới hạn nghiệp vụ production. Chưa có dọn ảnh mồ côi, storage bền vững phân tán, quét nội dung hay phê duyệt phát hành.
P0-3 nối ảnh kết quả, nháp/gửi/sửa/xác nhận, giữ phí/point, hai dấu thanh toán, ledger và lịch sử chỉ bằng tiền test. Xác nhận hóa đơn không tự hoàn tất việc. Người thực hiện nhận đủ tiền mới quyết toán, có thể trước dấu khách đã trả; đánh giá đủ điều kiện chỉ khi có cả hai dấu. API khách không lộ ví/nợ/thiếu phí của partner. Q02, ngân hàng, admin hoàn tất thay và tiền thật không được mở từ quyết định này.
Bằng chứng triển khai ở báo cáo B06-01 trong repo. Local/native, CI và UAT được ghi riêng; báo cáo không tải Drive.

## P1-01 A/B hiện hành — 13/10/2026

P1-01 A/B đã được chủ dự án duyệt ngày 13/10/2026. Chuẩn hiện hành cho đội ngũ và xác minh local/test là OpenAPI v0.1.11; các đoạn trước mô tả OTP Pending hoặc mã mẫu là lịch sử/phạm vi production, không phủ quyết phần local này.
Chỉ mở OTP purpose=verify trong phiên đăng nhập: email qua Mailpit trên máy, SMS qua hộp nhận mô phỏng. Mã ngẫu nhiên 6 số, hạn 5 phút, tối đa 5 lần sai; gửi lại sau 60 giây, 5 lần/liên hệ/giờ, 20 lần/tài khoản/giờ và 100 lần/IP/giờ. Mã gắn tài khoản, liên hệ và lần đăng nhập; gửi lại vô hiệu mã cũ. Xác minh email không xác minh điện thoại. Không thay email/điện thoại đã có hoặc chiếm liên hệ tài khoản khác. Chỉ DB DEMO/test cô lập và liên hệ cho phép; disabled mặc định, chặn production. Chưa mở OTP login/recover, MFA admin, email/SMS thật, billing hoặc tiền thật.
Chủ hoặc members.manage mời bằng email hoặc điện thoại, permissions=[]; lời mời 7 ngày, không trả token cho quản lý. Người nhận đăng nhập, xác minh đúng liên hệ rồi chủ động nhập token nhận lời. List/gửi lại/thu hồi kiểm quyền hiện hành; gửi lại thay token cũ. Nhận lời kiểm lại người mời; gia nhập lại dùng cùng membership nhưng không khôi phục quyền cũ. Lịch sử trạng thái pending/accepted/expired/revoked/replaced tách queued/submitted/failed/unknown của việc chuyển thư; submitted không chứng minh người nhận đã đọc.
GET /me/memberships phục vụ cả nhân viên thường và lịch sử đã rời. Cấp/thu hồi quyền dùng lý do, expected_version, Idempotency-Key và grant nhập lại mật khẩu qua POST /auth/reauthenticate. Grant hạn 5 phút, một lần, gắn user/family và scope membership.grants; refresh không gia hạn. Cấm tự sửa/sửa chủ/cấp vượt quyền; quyền thao tác ví cần wallet.read. Không coi nhập lại mật khẩu là MFA, không mở nghiệp vụ ngân hàng từ enum quyền.
Gỡ/tự rời: xem trước số việc cần bàn giao và version; xác nhận có lý do, máy chủ kiểm lại dưới khóa partner → job → invoice. Việc chưa có dấu nhận tiền về chờ phân công, chỉ bỏ nháp chưa gửi; giữ bản đã gửi/khóa, ledger, khoản giữ và dấu thanh toán. Việc đã nhận tiền giữ người thực hiện lịch sử. Thu hồi quyền ngay, giữ phòng chat cá nhân và không sao chép cho người mới. Đầu mối dùng Partner.version, có thể null để về cửa hàng; rời sẽ reset nếu đang là đầu mối. Gọi Internet vẫn chưa triển khai.
OTP/token lưu HMAC; liên hệ và nội dung hàng chờ mã hóa, xóa payload sau gửi/hết hạn. Worker khóa bản ghi để tránh hai lần gửi đồng thời; crash sau gửi vẫn có thể gây thư trùng, token chỉ dùng một lần. Audit bất biến ghi actor/lý do/quyền trước-sau/việc bàn giao, không ghi mật khẩu, token, OTP hay nội dung chat. Snapshot retry không chứa bí mật thô. UI Việt/Anh/Nhật đi từ Tài khoản → Xác minh liên hệ hoặc Đội ngũ → Thành viên/Lời mời/Đã rời/Quyền truy cập. Mất mạng giữ thao tác để thử lại; đổi tài khoản loại dữ liệu riêng. Bằng chứng code/native/CI/UAT được ghi riêng trong báo cáo repo, không coi spec là nghiệm thu.

## P1-02 — Tùy chọn nhắc lịch riêng, 14/10/2026

P1-02 ngày 14/10/2026: chủ dự án duyệt bổ sung công tắc nhắc lịch riêng và đồng bộ spec. Settings có bốn boolean bắt buộc message_push, call_push, service_push, reminder_push; mặc định true. reminder_push chỉ điều khiển gửi nhắc 24 giờ/1 giờ ra ngoài ứng dụng, độc lập service_push (công việc/hóa đơn). Tắt bất kỳ mục nào vẫn giữ inbox và lịch sử trong app; thông báo an toàn tài khoản không bị tắt. GET/PUT /me/notification-settings chỉ chính tài khoản, PUT giữ Idempotency-Key khi retry. Không duyệt provider, gửi push/email/SMS thật, billing hoặc production. Bằng chứng triển khai/local/native/CI/UAT được ghi riêng trong báo cáo B05-01 ở repo.


## RT-01A — cập nhật đã duyệt

RT-01A — 14/10/2026: chủ dự án đã duyệt triển khai Socket.IO 4, chỉ transport websocket, một NestJS instance. Path /v1/realtime/socket.io, namespace /; access token qua auth.token, không query URL. HTTP giữ thao tác ghi, ACK sau commit và lấy bù. Mỗi app một kết nối foreground, reconnect khi refresh, đóng khi logout/background; kiểm phiên và quyền hiện hành trước từng lần phát. Sự kiện là tín hiệu tải lại, không tự cộng tiền, unread hoặc quyết toán. Bốn công tắc push không tắt inbox/chat foreground. RT-01B/Redis, push ngoài app, gọi, presence/typing, provider/billing/production chưa mở.

Contract chi tiết: `docs/technical-design/realtime.json` v0.2, API v0.1.13. Dữ liệu thêm correlation_id và realtime_deliveries; unique theo event/user, lease riêng từng consumer; không dùng processed_at chung. QA-094–097 bổ sung kiểm realtime; không đổi trạng thái nghiệm thu của QA cũ. `notification.read.v1` chỉ lần đầu; thêm `invoice.revision_requested.v1`; invoice settled/payment_reported chuẩn hóa payload IDs/version, đọc eligibility/tiền bằng HTTP đúng quyền.


## MSG-01 — Tách Tin nhắn và Thông báo

MSG-01 — 15/10/2026, chủ dự án đã chốt: Tin nhắn và Thông báo có hai bộ đếm chưa đọc độc lập. Tin nhắn mới chỉ tăng badge Tin nhắn, không tạo mục trong inbox Thông báo và không tăng badge chuông. Badge Tin nhắn là tổng Conversation.unread trên tất cả phòng còn quyền truy cập, không phải số phòng; giữ định nghĩa unread hiện hành (không tính tin do chính mình gửi, mốc đọc theo sequence, gồm tin hệ thống của phòng). Badge Thông báo chỉ đếm mục chưa đọc ngoài chat, gồm công việc/hóa đơn/nhắc lịch và các loại khác đã được triển khai. Đọc một nhóm không đánh dấu đọc nhóm kia. Không hiển thị badge khi bằng 0; trên 99 hiện 99+. Sự kiện realtime chỉ yêu cầu tải lại HTTP, không cộng số trực tiếp; lấy bù khi reconnect/foreground, xóa số của tài khoản cũ khi đăng xuất/đổi tài khoản. Tắt message_push chỉ tắt push ngoài app, không tắt badge hoặc lịch sử chat. Không mở thêm provider hoặc production.
