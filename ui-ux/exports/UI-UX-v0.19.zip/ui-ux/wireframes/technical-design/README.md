# Thiết kế kỹ thuật chi tiết

Phiên bản 0.1 · Thiết kế để review. Q03 đã được chủ dự án chốt: Expo/React Native, React, NestJS, PostgreSQL/PostGIS. Các cấu trúc chi tiết bên dưới là đề xuất kỹ thuật của đợt này; chưa có backend và chưa chạy tiền thật.

## Đọc nhanh

1. Mở technical-design.html để xem sơ đồ và tra cứu theo nhóm.
2. 01-data-design.md + schema.sql: ERD vật lý, từ điển trường, ràng buộc và kế hoạch migration.
3. 02-api-realtime.md + openapi.json + realtime.json: hợp đồng giao tiếp và sự kiện.
4. 03-qa-plan.md + qa-cases.csv + rtm.json: kế hoạch kiểm thử, chưa phải kết quả test sản phẩm.
5. 04-backlog.md: thứ tự triển khai và điều kiện hoàn thành từng đợt.

Nguồn chuẩn nghiệp vụ: SRS v0.14, FR/NFR v0.16, UX v0.24, Q01/Q02/Q03 và phạm vi pending hiện hành. Sổ Excel quản lý liên kết/ảnh hưởng; không tự thay thế tài liệu gốc. JSON là nguồn dữ liệu cho viewer; sửa nội dung phải tái tạo Markdown/viewer/ZIP cùng đợt.

## Những gì chưa được coi là đã xong

- DDL được kiểm cú pháp không có nghĩa migration đã chạy trên PostgreSQL/PostGIS thật.
- OpenAPI hợp lệ không chứng minh backend có endpoint hoặc đã kiểm bảo mật.
- Test case và RTM là kế hoạch; tất cả ca sản phẩm đều Chưa chạy.
- Chưa chọn ORM, provider OTP/map/push/call/ngân hàng, phiên bản thư viện hay gói hạ tầng.
- Q02: khoản giữ treo vẫn pending đợt hiện tại, bắt buộc có cách xử lý qua báo cáo/admin và kiểm chứng trước tiền thật.
- Tiếp theo vẫn cần Design System/đặc tả field, runbook deploy/backup, runbook tài chính, lựa chọn tích hợp và dự toán.
