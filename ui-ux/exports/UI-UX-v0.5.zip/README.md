# Dịch vụ quanh bạn

Thư mục dự án chính từ 23/09/2026. React + Storybook đã được chủ dự án chọn cho công việc thiết kế UI; bản hiện tại vẫn là prototype dữ liệu giả.

| Vị trí | Nội dung |
|---|---|
| `ui-ux/prototype` | Mã React + Storybook phục vụ thiết kế, chưa phải ứng dụng production |
| `ui-ux/research` | Nghiên cứu giao diện, hướng thiết kế, brainstorm banner/voucher |
| `ui-ux/specs` | Đặc tả và phạm vi UX hiện hành |
| `ui-ux/wireframes` | Prototype nghiệp vụ và các trang hồ sơ đang phục vụ ở cổng 8765 |
| `ui-ux/archive` | Thử nghiệm Figma, Penpot và bằng chứng UX lịch sử |
| `ui-ux/exports` | Gói xuất thiết kế theo phiên bản |
| `docs/project-control/So-quan-ly-tai-lieu.xlsx` | Sổ quản lý chính cho toàn bộ dự án |
| `docs/project-docs` | Hồ sơ chung, user flow, screen flow, sơ đồ, kiến trúc |
| `docs/technical-design` | Thiết kế dữ liệu, API, QA, backlog |
| `apps/mobile` | Dành cho app Expo/React Native sau này; hiện chưa có mã sản phẩm |
| `apps/web` | Dành cho web khách/partner; hiện chưa có mã sản phẩm |
| `apps/admin` | Dành cho web quản trị; hiện chưa có mã sản phẩm |
| `services/api` | Dành cho backend NestJS; hiện chưa có mã sản phẩm |
| `packages` | Dành cho thành phần dùng chung khi có nhu cầu thực tế |
| `infra` | Dành cho cấu hình môi trường, triển khai và hạ tầng |
| `tools` | Công cụ tạo tài liệu và bằng chứng lịch sử |

Chạy từ `ui-ux/prototype`: `npm ci`, `npm run dev` (5178), `npm run storybook` (6006).
Build: `npm run build`, `npm run build-storybook`.

DOC-054 · Cấu trúc v0.1 ngày 23/09/2026. Các thư mục sản phẩm mới chỉ giữ chỗ, chưa khởi tạo framework hoặc monorepo build. Không cần thêm thư mục `frontend`: mobile, web và admin đã là ba ứng dụng giao diện. `services/api` là backend chung. Chỉ tách worker khi có nhu cầu và quyết định kiến trúc tương ứng. Sau này tokens có thể dùng chung qua `packages`, nhưng component web không tự chạy được trên React Native.

Không đổi repository hay cấu hình của các dự án khác. `outputs → docs`, `work → tools`, `apps/ui` và những đường dẫn thiết kế cũ trong docs là symlink tương thích. Ở workspace Codex cũ, outputs/work cũng dẫn về đây. Chỉ sửa đường dẫn chính trong bảng trên, không tạo bộ tài liệu thứ hai. Symlink có thể bỏ sau khi các công cụ lịch sử được chuyển hết; không chạy lại builder cũ để ghi đè nguồn hiện hành.

UI mới đã chọn hướng Dịch vụ khu phố: [Hướng thiết kế v0.2](ui-ux/research/ui-direction-v0.2.md). React đã dựng v0.4 với luồng khách hàng và partner/doanh nghiệp; sơ đồ bản đồ và dữ liệu vẫn minh họa. Sổ quản lý giữ trạng thái phê duyệt riêng với trạng thái cập nhật.

Ý tưởng tương lai: [Banner, quảng cáo và voucher](ui-ux/research/promotions-v0.1.md). Đã chốt: toàn bộ nhóm này để mở rộng tương lai, không làm trong phase đầu; chưa gán lịch triển khai. Point hiện hành không thay đổi.

Đợt UI-05: [Design system v0.1](ui-ux/specs/design-system.md) và [luồng khách hàng v0.3](ui-ux/specs/customer-journey.md). Xem hướng dẫn thử, kiểm chứng và giới hạn tại DOC-056.

Đợt UI-06: [Partner/doanh nghiệp v0.4](ui-ux/specs/partner-journey.md). Thanh chọn vai trò ở đầu bản thử dùng các tài khoản mẫu để kiểm tra dữ liệu hai phía.
