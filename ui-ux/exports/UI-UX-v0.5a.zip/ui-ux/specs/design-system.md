# Design system v0.2a — Dịch vụ khu phố

PLAN-006 · 23/09/2026 · Bộ nền tảng cho khách hàng và partner React v0.4a. Hướng thị giác đã chốt; chi tiết màn mới chờ chủ dự án xem. Chưa phải design system đầy đủ toàn hệ thống/admin hoặc React Native.

## Xem trực tiếp

Storybook → Dịch vụ quanh bạn → Thử giao diện → **Design system · bộ nền tảng**. Các thành phần được dùng thật trong luồng khách hàng, không chỉ là hình minh họa.

| Thành phần | Quy tắc hiện tại |
|---|---|
| Màu | Cobalt #2457D6: hành động; mực #16233B: nội dung; nền #F4F7FC; thành công #24634D; cảnh báo #925700; lỗi #B42318 |
| Chữ | Be Vietnam Pro, Arial fallback. Nội dung 16px, phụ 14px; chú thích mô phỏng 11–13px; tiêu đề 28–36px |
| Khoảng cách | 4/8/12/16/24/32/48px; panel 20px mobile, 24px desktop; bo góc 10–16px |
| Button | Primary/secondary/disabled; icon kèm nhãn; nút luồng mới tối thiểu 44px, nút chính 48px |
| Field | Nhãn luôn hiển thị; mô tả và lỗi cạnh nhóm nhập; hỗ trợ input/select/textarea/date/time |
| Status | Chờ phản hồi, kiểm tra hóa đơn, chờ thanh toán, hoàn tất. Có chữ/icon, không chỉ màu |
| Note | Hướng dẫn, trạng thái chờ, lỗi giữ dữ liệu để thử lại |
| Tiền | Nhóm nghìn, đơn vị đ, căn phải; vật tư/công riêng, số point trừ riêng, số trả trực tiếp nổi bật |
| Điều hướng | Desktop thanh ngang; mobile thanh dưới cố định: khách 4 mục, partner 4, quản lý doanh nghiệp 5, nhân viên 2; vùng nội dung chừa chỗ và safe area. Admin không nằm trong menu khách |
| Accessibility | Focus outline 3px; radio/fieldset có nhãn; modal Radix; reduced-motion; chưa nghiệm thu WCAG toàn bộ |

## Field trong luồng chính

| Màn | Trường | Điều kiện |
|---|---|---|
| Thuê | Dịch vụ | Từ kỹ năng partner mẫu; hiện mỗi partner có một kỹ năng minh họa |
| Thuê | Địa điểm | Nhà khách/địa điểm khác; tại cửa hàng khi partner mẫu có cửa hàng |
| Thuê | Địa chỉ | Bắt buộc, không chỉ khoảng trắng; chưa geocode/kiểm vùng phục vụ thật |
| Thuê | Làm ngay/hẹn trước | Hẹn trước bắt buộc ngày + giờ tương lai, tính giờ Hà Nội |
| Thuê | Ghi chú | Tùy chọn |
| Hóa đơn | Vật tư/tiền công | Chỉ đọc ở phía khách; thợ gửi sau ảnh kết quả |
| Hóa đơn | Point | Mặc định 0; số nguyên không âm; không vượt số dư khả dụng và tổng hóa đơn; khóa cùng hóa đơn |
| Yêu cầu sửa | Lý do | Bắt buộc trước khóa; hóa đơn chờ sửa không được xác nhận |
| Đánh giá | Sao/nội dung | 1–5 sao bắt buộc; nội dung tùy chọn; chỉ sau hai xác nhận thanh toán |

Nguồn mã: `prototype/src/journey.css`, `Journey.jsx`, `App.jsx`. Hiện dùng CSS variables; chưa trích token sang package dùng chung native/web. Đã bổ sung partner.css/Partner.jsx: công tắc nhận việc, danh sách việc, phân công, ảnh/nháp/hóa đơn và bảng ví. Admin và field toàn hệ thống chưa đầy đủ.

## Bổ sung partner v0.2

Công tắc nhận việc dùng switch + nhãn trạng thái; tab Công việc/Ví/Đội ngũ/Hồ sơ/Tin nhắn phụ thuộc quyền; nhân viên chỉ có Công việc/Tin nhắn. Form hóa đơn khóa phần tiền trước khi chọn ảnh; số công/vật tư nguyên không âm bắt buộc. Nhận tiền có checkbox kiểm tra số tiền. Yêu cầu rút chỉ nhận số nguyên dương trong khoản có thể rút. Trên mobile các panel xếp một cột, giữ cùng thuật ngữ với khách.
