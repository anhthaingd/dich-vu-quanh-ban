# So sánh Penpot và React + Storybook — v0.1

DOC-050/051/052. Thử nghiệm được chủ dự án yêu cầu ngày 23/09/2026. Hướng thiết kế chưa được chốt, chưa triển khai sản phẩm.

- React: http://127.0.0.1:5178/
- Storybook: http://127.0.0.1:6006/
- Penpot: https://design.penpot.app/#/workspace?team-id=b564c72c-f31f-81ec-8008-ae7a8797e0f6&project-id=b564c72c-f31f-81ec-8008-ae7aaaf1fe07&file-id=220f6449-533e-815b-8008-ae7c48b7a2d1&page-id=220f6449-533e-815b-8008-ae7c48b7a2d2

## Bản thử

React có tìm kiếm không dấu, nhóm dịch vụ, bộ lọc xác minh, bán kính 10/20/30 km, sắp xếp gần nhất/đánh giá, hồ sơ và chat trước thuê. Chat lưu trong bộ nhớ trang, không gửi người thật. Sơ đồ vị trí chỉ minh họa, không phải bản đồ thật. Địa điểm đang cố định Cầu Giấy. Form thuê và các trang công việc/tài khoản chưa được triển khai trong thử nghiệm. Đã đăng nhập giả lập. Xếp hạng kết hợp thực tế chưa triển khai, không thay đổi yêu cầu nghiệp vụ.

Penpot có hai bố cục desktop/mobile cùng hướng màu, cùng bài toán. Được nhập SVG qua UI trong file mới, không đụng file New File 1. SVG phân lớp rect/text nhưng text vẫn là SVG nhập, chưa là bộ text/component native có auto-layout/tokens. Vì vậy chưa coi đây là Design System Penpot hoàn chỉnh. Desktop minh họa ba thẻ trong bốn kết quả, mobile một thẻ; không phải bản sao pixel chính xác của React. Font Penpot Arial, React Be Vietnam Pro (Google Fonts, có Arial fallback).

## Kiểm chứng

- Build Vite và Storybook thành công; 6 stories: Desktop, Mobile, NoResults, VerifiedProfile, UnverifiedProfile, Buttons.
- Kiểm tra qua trình duyệt: Điện nước = 2, thêm xác minh = 1, chat trước thuê gửi tin mô phỏng, từ khóa không có trả trạng thái rỗng, xóa lọc/mở 20 km = 5.
- Kiểm responsive ở viewport 390px: document scrollWidth bằng clientWidth, không tràn ngang toàn trang; nhóm ngành cuộn ngang chủ ý.
- Penpot: đã lưu hai nhóm tim-tho-desktop/tim-tho-mobile và xác minh có layer svg-rect/svg-text. Giới hạn chỉnh sửa native ghi ở trên.
- Storybook axe ở story Desktop: đã sửa 5 vị trí chữ thiếu tương phản; lần quét lại có 0 violations, 25 passes, 2 inconclusive. Chưa kiểm mọi trạng thái; không tuyên bố đạt WCAG hoàn chỉnh.

## Chạy lại

Trong thư mục `react`: `npm ci`, `npm run dev`, `npm run storybook`. `npm run build` và `npm run build-storybook` tạo bản tĩnh. Lockfile giữ phiên bản. Cổng localhost chỉ xem được trên máy đang chạy.

Thư viện và plugin: xem [research.md](research.md). Sổ quản lý là điểm tra cứu chính; bản thử không thay thế BRD/SRS/UX đã duyệt. Không thay đổi cấu hình toàn cục hoặc dự án khác.
