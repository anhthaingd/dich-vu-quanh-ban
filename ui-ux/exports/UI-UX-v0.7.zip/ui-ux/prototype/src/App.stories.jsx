import {Journey,DesignSystem} from './Journey';
import React from'react';import{App,Button,ProviderCard,partners}from'./App';
export default{title:'Dịch vụ quanh bạn/Thử giao diện',component:App};
export const Desktop={render:()=> <Journey/>};
export const Mobile={render:()=> <Journey/>,globals:{viewport:{value:'iphone12',isRotated:false}}};
export const NoResults={render:()=> <Journey initialEmpty/>};
export const VerifiedProfile={render:()=> <div style={{maxWidth:740,padding:24}}><ProviderCard/></div>};
export const UnverifiedProfile={render:()=> <div style={{maxWidth:740,padding:24}}><ProviderCard partner={partners[3]}/></div>};
export const Buttons={render:()=> <div style={{display:'flex',gap:16,padding:32,flexWrap:'wrap'}}><Button>Nhắn tin trước</Button><Button secondary>Xem hồ sơ</Button><Button disabled>Gửi yêu cầu</Button></div>};

export const PartnerProfile={render:()=> <App initialView="profile"/>};
export const ChatBeforeHiring={render:()=> <App initialView="chat"/>};

export const DesignFoundations={name:'Design system · bộ nền tảng',render:()=> <DesignSystem/>};
export const WaitingForPartner={name:'Khách · chờ thợ nhận',render:()=> <Journey initialStage="pending"/>};
export const InvoiceReview={name:'Khách · kiểm tra hóa đơn',render:()=> <Journey initialStage="invoice"/>};
export const PaymentConfirmation={name:'Khách · xác nhận thanh toán',render:()=> <Journey initialStage="locked"/>};
export const ReviewAfterPayment={name:'Khách · đánh giá',render:()=> <Journey initialStage="completed"/>};
export const MobileInvoice={name:'Mobile · hóa đơn',render:()=> <Journey initialStage="invoice"/>,globals:{viewport:{value:'iphone12',isRotated:false}}};

export const PartnerSolo={name:'Partner · thợ tự do',render:()=> <Journey initialMode="solo"/>};
export const PartnerCompany={name:'Partner · doanh nghiệp',render:()=> <Journey initialMode="company"/>};
export const PartnerEmployee={name:'Partner · nhân viên',render:()=> <Journey initialMode="dung"/>};
export const PartnerMobile={name:'Mobile · partner',render:()=> <Journey initialMode="company"/>,globals:{viewport:{value:'iphone12',isRotated:false}}};

export const PartnerEditProfile={name:'Partner · chỉnh sửa hồ sơ',render:()=> <Journey initialMode="company" initialPartnerTab="profile"/>};
export const PartnerEditProfileMobile={name:'Mobile · chỉnh sửa hồ sơ',render:()=> <Journey initialMode="company" initialPartnerTab="profile"/>,globals:{viewport:{value:'iphone12',isRotated:false}}};
