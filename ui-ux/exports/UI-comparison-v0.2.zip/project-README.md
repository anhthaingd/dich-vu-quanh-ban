# Dịch vụ quanh bạn

Thư mục dự án chính từ 23/09/2026. React + Storybook đã được chủ dự án chọn cho công việc thiết kế UI; bản hiện tại vẫn là prototype dữ liệu giả.

| Vị trí | Nội dung |
|---|---|
| `outputs/project-control/So-quan-ly-tai-lieu.xlsx` | Sổ quản lý tài liệu chính, liên kết nguồn Drive và local |
| `apps/ui` | Lối vào React + Storybook, symlink đến `outputs/ui-comparison/react` |
| `outputs/project-docs` | Luồng người dùng, màn hình, sơ đồ, kiến trúc |
| `outputs/technical-design` | Thiết kế dữ liệu, API, QA, backlog |
| `outputs/wireframe-v0.1` | Prototype và các trang hồ sơ đang phục vụ ở cổng 8765 |
| `outputs/ui-comparison` | Bản thử React, Penpot và nghiên cứu giao diện |
| `work` | Công cụ tạo tài liệu và bằng chứng lịch sử; đọc nguồn hiện hành trước khi chạy lại |

Chạy từ `apps/ui`: `npm ci`, `npm run dev` (5178), `npm run storybook` (6006).
Build: `npm run build`, `npm run build-storybook`.

Không đổi repository hay cấu hình của các dự án khác. Chưa tạo backend hoặc app production. Thư mục `outputs` và `work` ở vị trí Codex cũ là liên kết đến đây, không phải bản sao quản lý riêng. Giữ liên kết này để các script lịch sử và localhost tiếp tục hoạt động. Những script cũ có dữ liệu cố định không được chạy lại để ghi đè sổ quản lý.

UI mới đã chọn hướng Dịch vụ khu phố: [Hướng thiết kế v0.2](outputs/ui-comparison/ui-direction-v0.2.md). React đã dựng v0.2; sơ đồ bản đồ và dữ liệu vẫn minh họa. Sổ quản lý giữ trạng thái phê duyệt riêng với trạng thái cập nhật.
