# UI/UX — Dịch vụ quanh bạn

Điểm vào phần thiết kế của dự án. Xem [README dự án](../README.md) để biết cấu trúc toàn hệ thống.

- `prototype/`: React + Storybook hiện hành. Chạy `npm run dev` hoặc `npm run storybook` tại đây.
- `research/`: nghiên cứu, hướng thiết kế và đề xuất; trạng thái phê duyệt ghi trong từng tài liệu.
- `specs/`: phạm vi UX hiện hành.
- `wireframes/`: prototype nghiệp vụ và các viewer HTML; phục vụ localhost:8765.
- `archive/`: bằng chứng và bản thử lịch sử, không tự dùng làm yêu cầu hiện hành.
- `exports/`: ZIP theo phiên bản; gói hiện hành UI-UX-v0.11.zip; các gói trước giữ làm lịch sử.

Sổ quản lý toàn dự án: `../docs/project-control/So-quan-ly-tai-lieu.xlsx`. Mã prototype nằm riêng, không đặt chung với `apps/web` để tránh nhầm dữ liệu giả với ứng dụng thật.

Hiện hành: React v0.9a, 31 stories. [Luồng khách hàng](specs/customer-journey.md) · [Design system](specs/design-system.md). Mở story Desktop/Mobile để thử xuyên suốt, hoặc các story hóa đơn/đánh giá để xem nhanh.

[Partner và doanh nghiệp](specs/partner-journey.md): nhận việc, phân công, hóa đơn, nhận tiền, ví. Cổng 6006 hiện phục vụ bản Storybook đã build; chạy build-storybook rồi tải lại để cập nhật.

Đợt 1: [Tài khoản, địa chỉ và đăng ký partner](specs/account-batch.md) — UI-12.
